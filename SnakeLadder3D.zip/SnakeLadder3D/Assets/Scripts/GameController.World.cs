using System.Collections.Generic;
using UnityEngine;

public partial class GameController
{
    Transform dice, marker, trophy; Material diceMat; float trophyT;
    class Seg { public Transform t; public Vector3 bp, side; public float ph; }
    class Amb { public Transform t; public float spd, ph; }
    List<Seg> segs = new List<Seg>();
    List<Amb> amb = new List<Amb>();

    Theme GetTheme(int w, int m)
    {
        var t = new Theme();
        int ww = m == 8 ? 7 : w;
        switch (ww)
        {
            case 0: t.bg = C(.45f, .75f, .6f); t.a = C(.55f, .8f, .35f); t.b = C(.33f, .58f, .25f); t.frame = C(.4f, .25f, .12f); t.floor = C(.12f, .38f, .14f); t.amb = C(.5f, .55f, .45f); t.fx = 5; break;
            case 1: t.bg = C(1f, .75f, .88f); t.a = C(1f, .6f, .75f); t.b = C(.7f, .9f, 1f); t.frame = C(1f, .4f, .6f); t.floor = C(1f, .85f, .9f); t.amb = C(.6f, .5f, .55f); t.fx = 6; break;
            case 2: t.bg = C(.75f, .88f, 1f); t.a = C(.95f, .97f, 1f); t.b = C(.65f, .82f, .95f); t.frame = C(.5f, .7f, .85f); t.floor = C(.9f, .95f, 1f); t.amb = C(.55f, .6f, .7f); t.fx = 1; break;
            case 3: t.bg = C(.02f, .02f, .1f); t.a = C(.25f, .25f, .5f); t.b = C(.15f, .15f, .35f); t.frame = C(.5f, .3f, .8f); t.floor = C(.02f, .02f, .08f); t.amb = C(.3f, .3f, .45f); t.fx = 4; t.glow = 0.2f; break;
            case 4: t.bg = C(.9f, .75f, .5f); t.a = C(.95f, .85f, .55f); t.b = C(.75f, .55f, .3f); t.frame = C(.85f, .65f, .15f); t.floor = C(.6f, .4f, .25f); t.amb = C(.55f, .5f, .4f); t.fx = 0; break;
            case 5: t.bg = C(.25f, .05f, .02f); t.a = C(.35f, .2f, .18f); t.b = C(.2f, .1f, .1f); t.frame = C(.8f, .25f, .05f); t.floor = C(.9f, .25f, 0f); t.floorGlow = 0.5f; t.amb = C(.45f, .3f, .25f); t.fx = 3; t.glow = 0.1f; break;
            case 6: t.bg = C(0f, .3f, .5f); t.a = C(.4f, .85f, .9f); t.b = C(.2f, .6f, .8f); t.frame = C(.9f, .6f, .4f); t.floor = C(.9f, .85f, .6f); t.amb = C(.35f, .5f, .6f); t.fx = 2; break;
            default: t.bg = C(.03f, 0f, .12f); t.a = C(.12f, .06f, .3f); t.b = C(.06f, .03f, .18f); t.frame = C(0f, .9f, 1f); t.floor = C(.02f, 0f, .07f); t.amb = C(.25f, .2f, .4f); t.fx = 4; t.glow = 0.5f; break;
        }
        if (m == 9) { t.a = C(1f, .85f, .35f); t.b = C(.85f, .62f, .12f); t.frame = C(.55f, .35f, .05f); t.glow = 0.15f; }
        return t;
    }

    void BuildWorld(bool lobby)
    {
        if (worldRoot != null) Destroy(worldRoot.gameObject);
        worldRoot = new GameObject("World").transform;
        segs.Clear(); amb.Clear(); trophy = null; trophyT = 0f;
        th = GetTheme(world, mode);
        cam.backgroundColor = th.bg;
        RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
        RenderSettings.ambientLight = th.amb;
        RenderSettings.fog = true; RenderSettings.fogMode = FogMode.ExponentialSquared;
        RenderSettings.fogColor = th.bg; RenderSettings.fogDensity = 0.008f;

        var lg = new GameObject("Sun"); lg.transform.SetParent(worldRoot, false);
        lg.transform.rotation = Quaternion.Euler(55f, -35f, 0f);
        sun = lg.AddComponent<Light>(); sun.type = LightType.Directional; sun.intensity = 1.15f;
        sun.color = Color.Lerp(Color.white, th.a, 0.25f); sun.shadowStrength = 0.7f;
        ApplyShadows();

        Prim(PrimitiveType.Cube, worldRoot, new Vector3(0, -0.05f, 0), new Vector3(70, 0.1f, 70), Mat(th.floor, 0.15f, th.floorGlow), "Floor");
        Prim(PrimitiveType.Cube, worldRoot, Vector3.zero, new Vector3(11f, 0.3f, 11f), Mat(th.frame, 0.6f, th.glow), "Frame");
        var mA = Mat(th.a, 0.75f, th.glow); var mB = Mat(th.b, 0.75f, th.glow);

        jumps.Clear(); jumpList.Clear();
        foreach (var pr in GameData.GetJumps(mode))
        {
            var j = new Jmp { from = pr[0], to = pr[1], snake = pr[1] < pr[0] };
            jumps[j.from] = j; jumpList.Add(j);
        }
        for (int n = 1; n <= 100; n++)
        {
            Vector3 p = TilePos(n); int r = (n - 1) / 10, c = (n - 1) % 10; bool alt = ((r + c) % 2 == 0);
            Material m = alt ? mA : mB; Jmp jj;
            if (n == 100) m = Mat(C(1f, .8f, .2f), 0.8f, 0.3f);
            else if (n == 1) m = Mat(C(.3f, .6f, 1f), 0.75f, th.glow);
            else if (jumps.TryGetValue(n, out jj))
                m = Mat(Color.Lerp(alt ? th.a : th.b, jj.snake ? C(1f, .25f, .25f) : C(.3f, 1f, .4f), 0.45f), 0.75f, th.glow);
            Prim(PrimitiveType.Cube, worldRoot, new Vector3(p.x, TOP - 0.05f, p.z), new Vector3(0.96f, 0.1f, 0.96f), m, "T" + n);
        }
        int si = 0;
        foreach (var j in jumpList) { if (j.snake) BuildSnake(j, si++); else BuildLadder(j); }

        Prim(PrimitiveType.Cylinder, worldRoot, new Vector3(DicePos.x, 0.02f, DicePos.z), new Vector3(2.4f, 0.03f, 2.4f), Mat(th.frame, 0.5f, th.glow), "Tray");
        BuildDice();
        Decor(); Ambient();
        marker = Prim(PrimitiveType.Cube, worldRoot, new Vector3(0, -50, 0), Vector3.one * 0.3f, Mat(C(1f, .85f, .2f), 0.8f, 0.8f), "Marker").transform;
        marker.rotation = Quaternion.Euler(45, 45, 0);
        for (int i = 0; i < players.Count; i++) BuildPawn(players[i], i, lobby);
    }

    // ---------- ladders & snakes ----------
    Vector3 LadPt(Jmp j, float k)
    {
        Vector3 p = Vector3.Lerp(TilePos(j.from), TilePos(j.to), k);
        p.y = TOP + 0.08f + k * 0.9f;
        return p;
    }

    void BuildLadder(Jmp j)
    {
        var root = new GameObject("Ladder" + j.from).transform; root.SetParent(worldRoot, false);
        Vector3 a = LadPt(j, 0f), b = LadPt(j, 1f);
        Vector3 dir = b - a; Vector3 flat = new Vector3(dir.x, 0, dir.z).normalized;
        Vector3 side = Vector3.Cross(Vector3.up, flat) * 0.2f;
        j.baseCol = C(.85f, .6f, .25f);
        var mr = Mat(j.baseCol, 0.5f, 0.2f); j.mats.Add(mr);
        var mrung = Mat(C(.95f, .8f, .4f), 0.4f, 0.2f); j.mats.Add(mrung);
        Bar(root, a + side, b + side, 0.05f, mr); Bar(root, a - side, b - side, 0.05f, mr);
        int rungs = Mathf.Max(2, (int)(dir.magnitude / 0.55f));
        for (int i = 1; i <= rungs; i++)
        {
            float k = i / (float)(rungs + 1);
            var g = Prim(PrimitiveType.Cube, root, Vector3.Lerp(a, b, k), new Vector3(0.44f, 0.05f, 0.06f), mrung, "Rung");
            g.transform.rotation = Quaternion.LookRotation(flat, Vector3.up);
        }
        foreach (float s in new[] { -1f, 1f })
            Bar(root, new Vector3(b.x + side.x * s, 0.15f, b.z + side.z * s), b + side * s, 0.05f, mr);
    }

    void BuildSnake(Jmp j, int idx)
    {
        var root = new GameObject("Snake" + j.from).transform; root.SetParent(worldRoot, false);
        Vector3 hp = TilePos(j.from), tp = TilePos(j.to);
        Vector3 dir = tp - hp; Vector3 flat = new Vector3(dir.x, 0, dir.z);
        Vector3 side = Vector3.Cross(Vector3.up, flat.normalized);
        int N = Mathf.Clamp((int)(dir.magnitude * 5f), 18, 56);
        j.path = new Vector3[N];
        float amp = Mathf.Min(0.9f, flat.magnitude * 0.1f + 0.3f);
        float waves = 1f + flat.magnitude / 5f; float ph = idx * 1.7f;
        for (int i = 0; i < N; i++)
        {
            float t = i / (float)(N - 1);
            Vector3 p = Vector3.Lerp(hp, tp, t);
            p += side * Mathf.Sin(t * Mathf.PI * 2f * waves + ph) * amp * Mathf.Sin(t * Mathf.PI);
            p.y = Mathf.Lerp(TOP + 0.55f, TOP + 0.1f, t);
            j.path[i] = p;
        }
        Color[] pal = { C(.1f, .6f, .2f), C(.7f, .2f, .6f), C(.9f, .5f, .1f), C(.2f, .4f, .8f), C(.6f, .6f, .1f), C(.8f, .15f, .15f) };
        Color bc = pal[idx % pal.Length];
        float glow = th.glow > 0f ? 0.6f : 0.05f;
        var m1 = Mat(bc, 0.6f, glow); var m2 = Mat(Color.Lerp(bc, Color.white, 0.45f), 0.6f, glow);
        j.baseCol = bc;
        for (int i = 1; i < N; i++)
        {
            float t = i / (float)(N - 1);
            float r = Mathf.Lerp(0.2f, 0.09f, t);
            var g = Prim(PrimitiveType.Sphere, root, j.path[i], Vector3.one * r * 2f, (i / 2) % 2 == 0 ? m1 : m2, "Seg");
            segs.Add(new Seg { t = g.transform, bp = j.path[i], side = side, ph = i * 0.6f + idx });
        }
        // head
        Vector3 fwd = j.path[0] - j.path[Mathf.Min(2, N - 1)]; fwd.y = 0;
        if (fwd.sqrMagnitude < 0.001f) fwd = Vector3.back;
        var head = new GameObject("Head").transform; head.SetParent(root, false);
        head.position = j.path[0]; head.rotation = Quaternion.LookRotation(fwd.normalized);
        j.headT = head;
        Prim(PrimitiveType.Sphere, head, Vector3.zero, new Vector3(0.55f, 0.38f, 0.62f), m1, "Skull");
        var mEye = Mat(C(1f, .9f, .1f), 0.8f, 1f); var mK = Mat(C(.02f, .02f, .02f), 0.3f);
        foreach (float s in new[] { -1f, 1f })
        {
            var e = Prim(PrimitiveType.Sphere, head, new Vector3(0.17f * s, 0.13f, 0.2f), Vector3.one * 0.14f, mEye, "Eye").transform;
            Prim(PrimitiveType.Sphere, e, new Vector3(0, 0, 0.4f), new Vector3(0.3f, 0.8f, 0.3f), mK, "Pupil");
            Prim(PrimitiveType.Cube, head, new Vector3(0.1f * s, -0.07f, 0.3f), new Vector3(0.04f, 0.1f, 0.04f), Mat(Color.white), "Fang");
        }
        var jaw = new GameObject("Jaw").transform; jaw.SetParent(head, false); jaw.localPosition = new Vector3(0, -0.1f, 0.05f);
        Prim(PrimitiveType.Cube, jaw, new Vector3(0, 0, 0.22f), new Vector3(0.34f, 0.07f, 0.46f), m2, "LowerJaw");
        Prim(PrimitiveType.Cube, head, new Vector3(0, -0.05f, 0.55f), new Vector3(0.04f, 0.02f, 0.3f), Mat(C(.9f, .1f, .15f), 0.4f), "Tongue");
        j.jaw = jaw;
    }

    // ---------- pawn ----------
    void BuildPawn(Pl p, int idx, bool lobby)
    {
        var root = new GameObject("Pawn" + idx).transform; root.SetParent(worldRoot, false);
        var inner = new GameObject("Inner").transform; inner.SetParent(root, false);
        Material mBody = Mat(p.color, 0.6f), mSkin = Mat(C(1f, .83f, .66f), 0.3f), mW = Mat(Color.white, 0.8f), mK = Mat(C(.05f, .05f, .08f), 0.5f);
        Prim(PrimitiveType.Capsule, inner, new Vector3(0, 0.42f, 0), new Vector3(0.5f, 0.32f, 0.5f), mBody, "Body");
        var head = Prim(PrimitiveType.Sphere, inner, new Vector3(0, 0.95f, 0), Vector3.one * 0.46f, mSkin, "Head").transform;
        foreach (float sx in new[] { -1f, 1f })
        {
            var eye = Prim(PrimitiveType.Sphere, head, new Vector3(0.22f * sx, 0.1f, 0.4f), Vector3.one * 0.28f, mW, "Eye").transform;
            Prim(PrimitiveType.Sphere, eye, new Vector3(0, 0, 0.38f), Vector3.one * 0.55f, mK, "Pupil");
        }
        Prim(PrimitiveType.Cube, head, new Vector3(0, -0.2f, 0.45f), new Vector3(0.3f, 0.07f, 0.1f), mK, "Mouth");
        var arms = new Transform[2];
        for (int s = 0; s < 2; s++)
        {
            float sx = s == 0 ? -1f : 1f;
            var piv = new GameObject("Arm").transform; piv.SetParent(inner, false); piv.localPosition = new Vector3(0.3f * sx, 0.62f, 0);
            Prim(PrimitiveType.Capsule, piv, new Vector3(0, -0.18f, 0), new Vector3(0.14f, 0.2f, 0.14f), mSkin, "ArmMesh");
            arms[s] = piv;
            Prim(PrimitiveType.Sphere, inner, new Vector3(0.12f * sx, 0.06f, 0.05f), new Vector3(0.2f, 0.12f, 0.3f), mK, "Foot");
        }
        var mGold = Mat(C(1f, .8f, .2f), 0.8f, 0.2f);
        switch (p.hat)
        {
            case 1:
                var mH = Mat(p.color * 0.7f + Color.white * 0.3f, 0.5f);
                Prim(PrimitiveType.Cylinder, inner, new Vector3(0, 1.22f, 0), new Vector3(0.34f, 0.06f, 0.34f), mH, "Hat");
                Prim(PrimitiveType.Cylinder, inner, new Vector3(0, 1.34f, 0), new Vector3(0.24f, 0.06f, 0.24f), mH, "Hat");
                Prim(PrimitiveType.Cylinder, inner, new Vector3(0, 1.46f, 0), new Vector3(0.12f, 0.06f, 0.12f), mH, "Hat");
                break;
            case 2:
                var mT = Mat(C(.08f, .08f, .1f), 0.6f);
                Prim(PrimitiveType.Cylinder, inner, new Vector3(0, 1.17f, 0), new Vector3(0.6f, 0.02f, 0.6f), mT, "Brim");
                Prim(PrimitiveType.Cylinder, inner, new Vector3(0, 1.35f, 0), new Vector3(0.38f, 0.17f, 0.38f), mT, "Crown");
                break;
            case 3:
                var mC = Mat(p.color, 0.5f);
                Prim(PrimitiveType.Sphere, inner, new Vector3(0, 1.12f, 0), new Vector3(0.52f, 0.36f, 0.52f), mC, "Cap");
                Prim(PrimitiveType.Cube, inner, new Vector3(0, 1.1f, 0.26f), new Vector3(0.34f, 0.03f, 0.3f), mC, "Visor");
                break;
            case 4:
                Prim(PrimitiveType.Cylinder, inner, new Vector3(0, 1.2f, 0), new Vector3(0.4f, 0.08f, 0.4f), mGold, "Crown");
                for (int i = 0; i < 5; i++)
                {
                    float a = i * Mathf.PI * 2f / 5f;
                    Prim(PrimitiveType.Cube, inner, new Vector3(Mathf.Cos(a) * 0.17f, 1.33f, Mathf.Sin(a) * 0.17f), new Vector3(0.07f, 0.14f, 0.07f), mGold, "Spike");
                }
                break;
        }
        root.localScale = Vector3.one * 0.85f * (mode == 7 ? 1.15f : 1f);
        p.root = root; p.inner = inner; p.head = head; p.armL = arms[0]; p.armR = arms[1];
        if (lobby) { root.position = LobbyPos(idx, players.Count); root.rotation = Quaternion.LookRotation(Vector3.back); }
        else { root.position = TilePos(p.pos) + p.offset; root.rotation = Quaternion.LookRotation(Vector3.forward); }
        p.anim = 0;
    }

    // ---------- dice ----------
    Vector2[] PipPattern(int v)
    {
        switch (v)
        {
            case 1: return new[] { new Vector2(0, 0) };
            case 2: return new[] { new Vector2(-1, -1), new Vector2(1, 1) };
            case 3: return new[] { new Vector2(-1, -1), new Vector2(0, 0), new Vector2(1, 1) };
            case 4: return new[] { new Vector2(-1, -1), new Vector2(1, 1), new Vector2(-1, 1), new Vector2(1, -1) };
            case 5: return new[] { new Vector2(-1, -1), new Vector2(1, 1), new Vector2(-1, 1), new Vector2(1, -1), new Vector2(0, 0) };
            default: return new[] { new Vector2(-1, -1), new Vector2(-1, 0), new Vector2(-1, 1), new Vector2(1, -1), new Vector2(1, 0), new Vector2(1, 1) };
        }
    }

    Quaternion FaceUp(int v)
    {
        switch (v)
        {
            case 1: return Quaternion.identity;
            case 6: return Quaternion.Euler(180, 0, 0);
            case 3: return Quaternion.Euler(0, 0, 90);
            case 4: return Quaternion.Euler(0, 0, -90);
            case 2: return Quaternion.Euler(-90, 0, 0);
            default: return Quaternion.Euler(90, 0, 0);
        }
    }

    void BuildDice()
    {
        var g = new GameObject("Dice"); g.transform.SetParent(worldRoot, false); dice = g.transform;
        int sk = Mathf.Clamp(Gi("dice", 0), 0, GameData.DiceNames.Length - 1);
        Color c = GameData.DiceColors[sk];
        diceMat = Mat(c, 0.8f, GameData.DiceGlow[sk]);
        Prim(PrimitiveType.Cube, dice, Vector3.zero, Vector3.one * 0.9f, diceMat, "Cube");
        float lum = c.r * 0.3f + c.g * 0.59f + c.b * 0.11f;
        var pm = Mat(lum > 0.5f ? C(.1f, .1f, .15f) : Color.white, 0.3f);
        Vector3[] normals = { Vector3.up, Vector3.down, Vector3.right, Vector3.left, Vector3.forward, Vector3.back };
        int[] vals = { 1, 6, 3, 4, 2, 5 };
        for (int f = 0; f < 6; f++)
        {
            Vector3 n = normals[f], t1, t2;
            if (Mathf.Abs(n.y) > 0.5f) { t1 = Vector3.right; t2 = Vector3.forward; }
            else if (Mathf.Abs(n.x) > 0.5f) { t1 = Vector3.up; t2 = Vector3.forward; }
            else { t1 = Vector3.right; t2 = Vector3.up; }
            foreach (var ab in PipPattern(vals[f]))
                Prim(PrimitiveType.Sphere, dice, n * 0.45f + t1 * ab.x * 0.22f + t2 * ab.y * 0.22f, Vector3.one * 0.15f, pm, "Pip");
        }
        dice.position = DicePos; dice.rotation = FaceUp(lastRoll);
    }

    void RefreshDiceSkin()
    {
        if (dice != null) Destroy(dice.gameObject);
        BuildDice();
    }

    // ---------- decor ----------
    void Decor()
    {
        var rnd = new System.Random(world * 7 + 3);
        int n = 16;
        for (int i = 0; i < n; i++)
        {
            float ang = i * Mathf.PI * 2f / n + (float)rnd.NextDouble() * 0.2f;
            float rad = 9.5f + (float)rnd.NextDouble() * 4f;
            Vector3 p = new Vector3(Mathf.Cos(ang) * rad, 0, Mathf.Sin(ang) * rad * 0.9f);
            if (p.z < -7f && Mathf.Abs(p.x) < 6f) continue;
            if (Mathf.Abs(p.x - DicePos.x) < 2.5f && Mathf.Abs(p.z - DicePos.z) < 2.5f) continue;
            Prop(mode == 8 ? 7 : world, p, rnd);
        }
    }

    void Prop(int w, Vector3 p, System.Random r)
    {
        float s = 0.8f + (float)r.NextDouble() * 0.8f;
        Vector3 up = Vector3.up;
        Color[] rc = { C(1f, .4f, .6f), C(.4f, .8f, 1f), C(1f, .85f, .3f), C(.6f, .5f, 1f), C(.4f, 1f, .6f) };
        Color col = rc[r.Next(rc.Length)];
        switch (w)
        {
            case 0:
                Prim(PrimitiveType.Cylinder, worldRoot, p + up * s, new Vector3(0.4f * s, s, 0.4f * s), Mat(C(.4f, .25f, .1f)), "Trunk");
                Prim(PrimitiveType.Sphere, worldRoot, p + up * 2.6f * s, Vector3.one * 2f * s, Mat(C(.15f, .55f + (float)r.NextDouble() * .2f, .2f)), "Leaves");
                break;
            case 1:
                Prim(PrimitiveType.Cylinder, worldRoot, p + up * 1.2f, new Vector3(0.12f, 1.2f, 0.12f), Mat(Color.white), "Stick");
                Prim(PrimitiveType.Sphere, worldRoot, p + up * 2.6f, Vector3.one * 1.3f * s, Mat(col, 0.8f, 0.2f), "Candy");
                break;
            case 2:
                var wh = Mat(C(.97f, .97f, 1f), 0.4f);
                Prim(PrimitiveType.Sphere, worldRoot, p + up * 0.8f * s, Vector3.one * 1.6f * s, wh, "Snow");
                Prim(PrimitiveType.Sphere, worldRoot, p + up * 2f * s, Vector3.one * 1.1f * s, wh, "Snow");
                Prim(PrimitiveType.Sphere, worldRoot, p + up * 2.9f * s, Vector3.one * 0.7f * s, wh, "Snow");
                Prim(PrimitiveType.Cube, worldRoot, p + up * 2.9f * s + new Vector3(0, 0, -0.35f * s), new Vector3(0.1f, 0.1f, 0.3f) * s, Mat(C(1f, .5f, .1f)), "Nose");
                break;
            case 3:
                Prim(PrimitiveType.Sphere, worldRoot, p + up * (3f + (float)r.NextDouble() * 4f), Vector3.one * 3f * s, Mat(col, 0.4f, 0.25f), "Planet");
                break;
            case 4:
                Prim(PrimitiveType.Cylinder, worldRoot, p + up * 1.3f * s, new Vector3(0.9f, 1.3f * s, 0.9f), Mat(C(.95f, .88f, .7f)), "Pillar");
                Prim(PrimitiveType.Cube, worldRoot, p + up * 2.7f * s, new Vector3(1.5f, 0.3f, 1.5f), Mat(C(1f, .8f, .2f), 0.8f, 0.2f), "Cap");
                break;
            case 5:
                Prim(PrimitiveType.Sphere, worldRoot, p + up * 0.6f, new Vector3(2f * s, 1.5f * s, 2f * s), Mat(C(.15f, .1f, .1f)), "Rock");
                Prim(PrimitiveType.Sphere, worldRoot, p + up * 1.3f * s, Vector3.one * 0.6f, Mat(C(1f, .4f, .05f), 0.5f, 1f), "Lava");
                break;
            case 6:
                for (int k = 0; k < 3; k++)
                {
                    float h = 0.8f + (float)r.NextDouble() * 1.4f;
                    Vector3 q = p + new Vector3(k * 0.4f - 0.4f, 0, 0);
                    Prim(PrimitiveType.Cylinder, worldRoot, q + up * h * 0.5f, new Vector3(0.25f, h * 0.5f, 0.25f), Mat(col, 0.5f, 0.2f), "Coral");
                    Prim(PrimitiveType.Sphere, worldRoot, q + up * h, Vector3.one * 0.4f, Mat(col, 0.5f, 0.2f), "Coral");
                }
                break;
            default:
                Prim(PrimitiveType.Cylinder, worldRoot, p + up * 1.5f, new Vector3(0.5f, 1.5f, 0.5f), Mat(col, 0.7f, 1f), "NeonPillar");
                break;
        }
    }

    void Ambient()
    {
        if (th.fx == 0) return;
        int n = Gi("gfx", 2) >= 2 ? 60 : 25;
        Material m;
        switch (th.fx)
        {
            case 1: m = Mat(Color.white, 0.2f, 0.5f); break;
            case 2: m = Mat(C(.7f, .95f, 1f), 0.9f, 0.3f); break;
            case 3: m = Mat(C(1f, .45f, .1f), 0.2f, 1.5f); break;
            case 4: m = Mat(Color.white, 0.2f, 1.2f); break;
            case 5: m = Mat(C(.9f, 1f, .3f), 0.2f, 1.5f); break;
            default: m = Mat(C(1f, .5f, .8f), 0.5f, 0.4f); break;
        }
        for (int i = 0; i < n; i++)
        {
            var g = Prim(PrimitiveType.Sphere, worldRoot, Vector3.zero, Vector3.one * (th.fx == 4 ? 0.3f : 0.12f), th.fx == 6 ? Mat(Color.HSVToRGB(Random.value, 0.5f, 1f), 0.5f, 0.4f) : m, "Amb");
            g.GetComponent<Renderer>().shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            Vector3 pos = new Vector3(Random.Range(-13f, 13f), Random.Range(0f, 12f), Random.Range(-13f, 13f));
            if (th.fx == 4) { pos = Random.onUnitSphere * 28f; pos.y = Mathf.Abs(pos.y) + 2f; }
            g.transform.position = pos;
            amb.Add(new Amb { t = g.transform, spd = Random.Range(0.4f, 1.2f), ph = Random.Range(0f, 6f) });
        }
    }

    // ---------- per-frame animation ----------
    void AnimatePawns()
    {
        float t = Time.time;
        for (int i = 0; i < players.Count; i++)
        {
            var p = players[i]; if (p.root == null) continue;
            float ph = i * 1.3f;
            Vector3 ip = Vector3.zero; float rotY = 0, aL = 0, aR = 0, tilt = 0;
            switch (p.anim)
            {
                case 0: ip.y = Mathf.Sin(t * 2f + ph) * 0.02f; aL = Mathf.Sin(t * 2f + ph) * 8f; aR = -aL; tilt = Mathf.Sin(t * 1.3f + ph) * 6f; break;
                case 1: ip.y = Mathf.Abs(Mathf.Sin(t * 10f)) * 0.05f; aL = Mathf.Sin(t * 12f) * 40f; aR = -aL; break;
                case 2:
                    ip.y = Mathf.Abs(Mathf.Sin(t * 7f + ph)) * 0.35f;
                    aL = -150f + Mathf.Sin(t * 14f) * 25f; aR = -150f - Mathf.Sin(t * 14f) * 25f;
                    rotY = (p.personaIdx % 2 == 0) ? t * 400f : Mathf.Sin(t * 6f) * 30f;
                    if (page == Page.Game && cam != null)
                    {
                        Vector3 d = cam.transform.position - p.root.position; d.y = 0;
                        if (d.sqrMagnitude > 0.01f) p.root.rotation = Quaternion.Slerp(p.root.rotation, Quaternion.LookRotation(d), Time.deltaTime * 5f);
                    }
                    break;
                case 3: tilt = 25f; aL = 10f; aR = 10f; ip.y = -0.02f; break;
                case 4: ip.y = Mathf.Abs(Mathf.Sin(t * 8f)) * 0.04f; aL = -120f + Mathf.Sin(t * 9f) * 50f; aR = -120f - Mathf.Sin(t * 9f) * 50f; break;
            }
            p.inner.localPosition = ip; p.inner.localRotation = Quaternion.Euler(0, rotY, 0);
            p.armL.localRotation = Quaternion.Euler(aL, 0, 0); p.armR.localRotation = Quaternion.Euler(aR, 0, 0);
            p.head.localRotation = Quaternion.Euler(tilt, 0, 0);
        }
        if (marker != null)
        {
            bool on = page == Page.Game && !matchOver && cur < players.Count && players[cur].root != null && !players[cur].eliminated;
            if (on)
            {
                marker.position = players[cur].root.position + Vector3.up * (1.9f + Mathf.Sin(t * 4f) * 0.1f);
                marker.Rotate(0, 120f * Time.deltaTime, 0, Space.World);
            }
            else marker.position = new Vector3(0, -50, 0);
        }
    }

    void AnimateWorld(float dt)
    {
        float tm = Time.time;
        foreach (var s in segs)
            if (s.t != null) s.t.position = s.bp + s.side * Mathf.Sin(tm * 4f + s.ph) * 0.06f + Vector3.up * Mathf.Sin(tm * 3f + s.ph) * 0.02f;
        foreach (var a in amb)
        {
            if (a.t == null) continue;
            Vector3 p = a.t.position;
            switch (th.fx)
            {
                case 1: case 6: p.y -= a.spd * dt; p.x += Mathf.Sin(tm + a.ph) * 0.3f * dt; if (p.y < 0f) p.y = 12f; break;
                case 2: case 3: p.y += a.spd * dt; p.x += Mathf.Sin(tm * 1.3f + a.ph) * 0.4f * dt; if (p.y > 12f) p.y = 0f; break;
                case 5: p.y += Mathf.Sin(tm + a.ph) * 0.4f * dt; p.x += Mathf.Cos(tm * 0.7f + a.ph) * 0.5f * dt; break;
                case 4: a.t.localScale = Vector3.one * (0.25f + 0.12f * Mathf.Sin(tm * 2f + a.ph)); break;
            }
            a.t.position = p;
        }
        if (shader != null && shader.name == "Standard")
            foreach (var j in jumpList)
            {
                if (j.snake) continue;
                j.glowCur = Mathf.MoveTowards(j.glowCur, j.glowTarget, dt * 3f);
                foreach (var m in j.mats) m.SetColor("_EmissionColor", j.baseCol * (0.2f + j.glowCur));
            }
        if (dice != null && diceMat != null)
        {
            if (Gi("dice", 0) == 11) diceMat.color = Color.HSVToRGB(Mathf.Repeat(tm * 0.2f, 1f), 0.6f, 1f);
            if (mode == 5 && Random.value < 0.15f) Burst(dice.position, -1, 1, 1f, 0.8f, -0.3f, 0.06f);
            if (!rolling) dice.position = DicePos + Vector3.up * Mathf.Sin(tm * 2f) * 0.03f;
        }
        if (trophy != null)
        {
            trophyT = Mathf.Min(1f, trophyT + Time.unscaledDeltaTime * 1.5f);
            trophy.localScale = Vector3.one * trophyT * 1.3f;
            trophy.Rotate(0, 90f * Time.unscaledDeltaTime, 0, Space.World);
        }
    }

    void BuildTrophy(Pl w)
    {
        var t = new GameObject("Trophy").transform; t.SetParent(worldRoot, false);
        t.position = w.root.position + Vector3.up * 2.4f; t.localScale = Vector3.zero;
        var gold = Mat(C(1f, .8f, .15f), 0.9f, 0.3f);
        Prim(PrimitiveType.Cylinder, t, new Vector3(0, -0.3f, 0), new Vector3(0.5f, 0.04f, 0.5f), gold, "Base");
        Prim(PrimitiveType.Cylinder, t, new Vector3(0, -0.15f, 0), new Vector3(0.1f, 0.12f, 0.1f), gold, "Stem");
        Prim(PrimitiveType.Sphere, t, new Vector3(0, 0.1f, 0), new Vector3(0.55f, 0.45f, 0.55f), gold, "Cup");
        foreach (float s in new[] { -1f, 1f })
            Prim(PrimitiveType.Sphere, t, new Vector3(0.3f * s, 0.1f, 0), new Vector3(0.18f, 0.18f, 0.06f), gold, "Handle");
        trophy = t; trophyT = 0f;
    }
}
