using UnityEngine;

public partial class GameController
{
    AudioSource sfx, music;
    AudioClip sClick, sRattle, sLand, sHop, sLadder, sSnake, sWin, sLose, sMusic;

    bool MusicOn { get { return Gi("musicOn", 1) == 1; } }
    bool SfxOn { get { return Gi("sfxOn", 1) == 1; } }
    float MusVol { get { return PlayerPrefs.GetFloat("musVol", 0.5f); } }
    float SfxVol { get { return PlayerPrefs.GetFloat("sfxVol", 1f); } }

    AudioClip Gen(string name, float dur, System.Func<float, float> f)
    {
        int sr = 22050, n = (int)(dur * sr);
        var d = new float[n];
        for (int i = 0; i < n; i++) d[i] = Mathf.Clamp(f(i / (float)sr), -1f, 1f);
        var c = AudioClip.Create(name, n, 1, sr, false);
        c.SetData(d, 0);
        return c;
    }

    float Env(float t, float dur) { return Mathf.Clamp01(t * 80f) * Mathf.Clamp01((dur - t) * 20f); }
    float Sin(float f, float t) { return Mathf.Sin(2f * Mathf.PI * f * t); }

    void InitAudio()
    {
        sfx = gameObject.AddComponent<AudioSource>(); sfx.playOnAwake = false;
        music = gameObject.AddComponent<AudioSource>(); music.playOnAwake = false; music.loop = true;
        sClick = Gen("click", 0.07f, t => Sin(900f, t) * Env(t, 0.07f) * 0.5f);
        sRattle = Gen("rattle", 0.9f, t => (Random.value * 2f - 1f) * 0.45f * (0.5f + 0.5f * Sin(18f, t)) * (1f - t / 0.9f));
        sLand = Gen("land", 0.2f, t => Sin(120f, t) * Mathf.Exp(-t * 18f) * 0.9f);
        sHop = Gen("hop", 0.12f, t => Mathf.Sin(2f * Mathf.PI * (350f * t + 1500f * t * t)) * Env(t, 0.12f) * 0.4f);
        float[] arp = { 523.3f, 659.3f, 784f, 1046.5f };
        sLadder = Gen("ladder", 0.8f, t => Sin(arp[Mathf.Min(3, (int)(t / 0.2f))], t) * Env(t % 0.2f, 0.2f) * 0.45f);
        sSnake = Gen("snake", 1.0f, t => ((Random.value * 2f - 1f) * 0.3f + Mathf.Sin(2f * Mathf.PI * (500f * t - 190f * t * t)) * 0.3f) * Env(t, 1.0f));
        float[] ch = { 523.3f, 659.3f, 784f, 1046.5f, 784f, 1046.5f, 1318.5f, 1568f };
        sWin = Gen("win", 1.6f, t => (Sin(ch[Mathf.Min(7, (int)(t / 0.2f))], t) * 0.35f + Sin(ch[Mathf.Min(7, (int)(t / 0.2f))] * 0.5f, t) * 0.2f) * Env(t % 0.2f, 0.2f) * Mathf.Clamp01(1.6f - t));
        sLose = Gen("lose", 0.7f, t => Mathf.Sin(2f * Mathf.PI * (400f * t - 300f * t * t)) * Env(t, 0.7f) * 0.45f);
        float[] semis = { 0, 2, 4, 7, 9 };
        int[] seq = { 0, 2, 4, 2, 3, 1, 0, 1, 4, 3, 2, 1, 2, 0, 2, 4 };
        sMusic = Gen("music", 8f, t =>
        {
            int ni = Mathf.Min(15, (int)(t / 0.5f));
            float f = 261.6f * Mathf.Pow(2f, semis[seq[ni]] / 12f);
            float local = t % 0.5f;
            float e = Mathf.Exp(-local * 4f);
            float melody = (Sin(f, t) + 0.3f * Sin(f * 2f, t)) * 0.18f * e;
            float bass = Sin(130.8f * ((ni / 4) % 2 == 0 ? 1f : 0.75f), t) * 0.1f;
            return melody + bass;
        });
        music.clip = sMusic;
        ApplyAudio();
    }

    void ApplyAudio()
    {
        music.volume = MusVol * 0.6f;
        if (MusicOn) { if (!music.isPlaying) music.Play(); } else music.Stop();
    }

    void Play(AudioClip c, float vol = 1f)
    {
        if (c != null && sfx != null && SfxOn) sfx.PlayOneShot(c, vol * SfxVol);
    }
}
