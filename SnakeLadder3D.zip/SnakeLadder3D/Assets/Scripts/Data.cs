using System.Collections.Generic;
using UnityEngine;

public enum Page { Home, Setup, Game, Shop, Rewards, Stats, Settings }
public enum CamMode { Iso, Top, Follow, Cinematic }
public enum CamOv { None, Dice, Snake, Ladder, Victory }

public class Pl
{
    public string name = "", persona = "";
    public Color color = Color.white;
    public bool human, eliminated;
    public int pos, hat, rolls, ladders, snakes, points, personaIdx;
    public float delay = 0.8f;
    public Transform root, inner, head, armL, armR;
    public Vector3 offset;
    public int anim;
    public string bubble = "";
    public float bubbleUntil;
}

public class Jmp
{
    public int from, to;
    public bool snake;
    public Vector3[] path;
    public Transform jaw, headT;
    public List<Material> mats = new List<Material>();
    public Color baseCol;
    public float glowCur, glowTarget;
}

public class Theme
{
    public Color bg, a, b, frame, floor, amb;
    public int fx;
    public float glow, floorGlow;
}

public static class GameData
{
    public static readonly string[] Modes = { "Classic", "Rapid", "Challenge", "Tournament", "Survival", "Lucky Dice", "Hardcore", "Kids", "Night", "Golden" };
    public static readonly string[] ModeDesc = {
        "Traditional 100-tile Snake & Ladder.",
        "Fast animations, quick games.",
        "Win within 30 of your own rolls for a bonus.",
        "3 rounds. Points for every rank. Best total wins.",
        "Every 6 rounds the last player is eliminated.",
        "Glowing lucky dice with sparkles. Results stay fair.",
        "Extra snakes, fewer ladders.",
        "Bright, friendly board with fewer snakes.",
        "Dark neon board with glowing snakes and ladders.",
        "Luxury golden board." };
    public static readonly string[] Worlds = { "Jungle", "Candy", "Snow", "Space", "Ancient", "Volcano", "Underwater", "Neon Cyber" };
    public static readonly string[] Hats = { "None", "Party", "Top Hat", "Cap", "Crown" };

    public static readonly string[] DiceNames = { "Classic", "Golden", "Diamond", "Neon", "Fire", "Ice", "Emerald", "Ruby", "Galaxy", "Candy", "Shadow", "Rainbow" };
    public static readonly Color[] DiceColors = {
        new Color(0.96f,0.96f,0.94f), new Color(1f,0.8f,0.2f), new Color(0.7f,0.95f,1f), new Color(0.1f,1f,0.5f),
        new Color(1f,0.35f,0.05f), new Color(0.6f,0.85f,1f), new Color(0.1f,0.7f,0.3f), new Color(0.85f,0.05f,0.2f),
        new Color(0.35f,0.15f,0.7f), new Color(1f,0.5f,0.75f), new Color(0.12f,0.12f,0.15f), new Color(1f,0.4f,0.4f) };
    public static readonly float[] DiceGlow = { 0f, 0.25f, 0.35f, 0.8f, 0.8f, 0.3f, 0.2f, 0.3f, 0.5f, 0.1f, 0f, 0.5f };
    public static readonly int[] DicePrice = { 0, 200, 350, 250, 300, 300, 150, 150, 400, 100, 200, 500 };

    public static readonly string[] BotNames = { "Rocky", "Shelly", "Jokey", "Prof. Brain", "Lucky", "Champ" };
    public static readonly string[] BotPersona = { "Aggressive", "Defensive", "Funny", "Intelligent", "Lucky", "Competitive" };
    public static readonly float[] BotDelay = { 0.5f, 1.2f, 0.9f, 1.0f, 0.7f, 0.6f };
    // ladder, snake, win, six
    public static readonly string[][] BotLines = {
        new[]{ "Out of my way!", "I'll crush that snake!", "Unstoppable!", "SIX! Fear me!" },
        new[]{ "Slow and steady.", "Ouch... still safe.", "Careful play pays!", "A safe six." },
        new[]{ "Wheee! Elevator!", "Slippery slide, hehe!", "I won! Pizza time!", "Six! Dice love me." },
        new[]{ "Calculated.", "Statistically unlucky.", "Elementary.", "Probability 1 in 6." },
        new[]{ "Luck is my name!", "Lucky me... oh wait.", "Born lucky!", "Six! Of course." },
        new[]{ "Ahead of you all!", "Just a setback.", "Champion again!", "Six! Catch me!" } };
    public static readonly string[] HumanLines = { "Yay! Climbing!", "Oh no! A snake!", "I did it!", "Six!" };

    public static readonly Color[] PlayerColors = {
        new Color(0.9f,0.15f,0.15f), new Color(0.15f,0.4f,0.95f), new Color(0.15f,0.75f,0.25f), new Color(1f,0.85f,0.1f) };
    public static readonly Vector3[] Offsets = {
        new Vector3(-0.2f,0,-0.2f), new Vector3(0.2f,0,-0.2f), new Vector3(-0.2f,0,0.2f), new Vector3(0.2f,0,0.2f) };

    public static List<int[]> GetJumps(int mode)
    {
        var l = new List<int[]> {
            new[]{1,38}, new[]{4,14}, new[]{9,31}, new[]{21,42}, new[]{28,84}, new[]{36,44}, new[]{51,67}, new[]{71,91}, new[]{80,100},
            new[]{16,6}, new[]{47,26}, new[]{49,11}, new[]{56,53}, new[]{62,19}, new[]{64,60}, new[]{87,24}, new[]{93,73}, new[]{95,75}, new[]{98,78} };
        if (mode == 6)
        {
            l.RemoveAll(j => j[0] == 28 || j[0] == 71);
            l.Add(new[] { 27, 7 }); l.Add(new[] { 74, 34 }); l.Add(new[] { 89, 68 }); l.Add(new[] { 58, 40 });
        }
        if (mode == 7) l.RemoveAll(j => j[0] == 98 || j[0] == 95 || j[0] == 87 || j[0] == 62 || j[0] == 49);
        return l;
    }
}
