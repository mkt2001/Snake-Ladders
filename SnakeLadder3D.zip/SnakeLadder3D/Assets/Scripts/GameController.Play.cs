using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public partial class GameController
{
    // ---------- fx ----------
    class Spark { public Transform t; public Vector3 v; public float life, max, grav; public Vector3 spin; }
    List<Spark> sparks = new List<Spark>();
    Material[] fxMats;

    void InitFxMats()
    {
        Color[] cs = { C(1f, .8f, .2f), C(1f, .2f, .2f), C(.2f, 1f, .3f), C(.3f, .5f, 1f), C(1f, 1f, .3f), C(1f, .4f, .8f), Color.white, C(.3f, 1f, 1f) };
        fxMats = new Material[cs.Length];
        for (int i = 0; i < cs.Length; i++) fxMats[i] = Mat(cs[i], 0.5f, 0.8f);
    }

    void Burst(Vector3 pos, int mi, int n, float speed, float life, float grav, float size)
    {
        for (int i = 0; i < n && sparks.Count < 400; i++)
        {
            var g = GameObject.CreatePrimitive(PrimitiveType.Cube);
            var col = g.GetComponent<Collider>(); if (col != null) Destroy(col);
            var r = g.GetComponent<Renderer>();
            r.sharedMaterial = fxMats[mi < 0 ? Random.Range(0, fxMats.Length) : mi % fxMats.Length];
            r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            g.transform.SetParent(fxRoot, false);
            g.transform.position = pos;
            g.transform.localScale = Vector3.one * size * Random.Range(0.6f, 1.2f);
            sparks.Add(new Spark { t = g.transform, v = Random.onUnitSphere * speed * Random.Range(0.4f, 1f), life = life * Random.Range(0.7f, 1f), max = life, grav = grav, spin = Random.onUnitSphere * 400f });
        }
    }

    void UpdateFx(float dt)
    {
        for (int i = sparks.Count - 1; i >= 0; i--)
        {
            var s = sparks[i];
            s.life -= dt;
            if (s.life <= 0f || s.t == null) { if (s.t != null) Destroy(s.t.gameObject); sparks.RemoveAt(i); continue; }
            s.v.y += s.grav * dt;
            s.t.position += s.v * dt;
            s.t.Rotate(s.spin * dt);
            if (s.life < 0.4f) s.t.localScale *= 0.92f;
        }
    }

    void ClearFx()
    {
        foreach (var s in sparks) if (s.t != null) Destroy(s.t.gameObject);
        sparks.Clear();
    }

    // ---------- small helpers ----------
    IEnumerator Wait(float s) { float t = 0f; while (t < s) { t += Time.deltaTime; yield return null; } }

    void Log(string s) { history.Insert(0, s); if (history.Count > 8) history.RemoveAt(8); }
    string Line(Pl p, int i) { return (p.human ? GameData.HumanLines : GameData.BotLines[p.personaIdx])[i]; }
    void Say(Pl p, string t) { p.bubble = t; p.bubbleUntil = Time.time + 2.2f; }
    void Vibe() { if (Gi("vib", 1) == 1 && Application.isMobilePlatform) Handheld.Vibrate(); }

    // ---------- match flow ----------
    IEnumerator MatchLoop()
    {
        yield return Wait(0.8f);
        while (!matchOver)
        {
            var p = players[cur];
            if (p.eliminated) { cur = (cur + 1) % players.Count; continue; }
            camOv = CamOv.None;
            if (p.human)
            {
                waitRoll = true; rollPressed = false;
                while (!rollPressed) yield return null;
                waitRoll = false;
            }
            else yield return Wait(p.delay / Spd);

            yield return RollDice(p);
            int r = lastRoll; p.rolls++;
            Log(p.name + " rolled " + r);
            if (r == 6) Say(p, Line(p, 3));
            yield return MoveFlow(p, r);
            camOv = CamOv.None; activeJmp = null;
            if (p.pos >= 100) { matchOver = true; StartCoroutine(EndMatch(p)); yield break; }

            bool again = sixAgain && r == 6;
            if (!again)
            {
                int prev = cur;
                do { cur = (cur + 1) % players.Count; } while (players[cur].eliminated);
                if (cur <= prev) { roundNo++; if (mode == 4 && roundNo % 6 == 0) yield return Eliminate(); }
            }
            yield return Wait(0.25f / Spd);
        }
    }

    IEnumerator Eliminate()
    {
        int act = 0; foreach (var p in players) if (!p.eliminated) act++;
        if (act <= 2) yield break;
        Pl low = null;
        foreach (var p in players) if (!p.eliminated && (low == null || p.pos < low.pos)) low = p;
        low.eliminated = true; low.anim = 3; Say(low, "Eliminated!"); Log(low.name + " eliminated");
        Play(sLose);
        yield return Wait(1.1f);
        if (low.root != null) low.root.gameObject.SetActive(false);
        if (players[cur] == low) { do { cur = (cur + 1) % players.Count; } while (players[cur].eliminated); }
    }

    IEnumerator RollDice(Pl p)
    {
        lastRoll = Random.Range(1, 7);       // fair dice: 1..6
        showRoll = false; rolling = true;
        camOv = autoCam ? CamOv.Dice : CamOv.None;
        Play(sRattle);
        float dur = 1.05f / Spd, t = 0f;
        Vector3 av = Random.onUnitSphere * 720f;
        Vector3 basePos = DicePos;
        while (t < dur)
        {
            t += Time.deltaTime;
            float k = Mathf.Clamp01(t / dur);
            float h = Mathf.Abs(Mathf.Sin(k * Mathf.PI * 3f)) * (1f - k) * 1.6f;
            dice.position = basePos + Vector3.up * h;
            dice.Rotate(av * Time.deltaTime * (1f - k * 0.7f), Space.World);
            yield return null;
        }
        Quaternion from = dice.rotation;
        Quaternion to = Quaternion.Euler(0, Random.Range(0f, 360f), 0) * FaceUp(lastRoll);
        t = 0f;
        while (t < 1f)
        {
            t += Time.deltaTime / 0.25f;
            dice.rotation = Quaternion.Slerp(from, to, Mathf.Clamp01(t));
            dice.position = Vector3.Lerp(dice.position, basePos, 0.3f);
            yield return null;
        }
        dice.position = basePos; dice.rotation = to;
        rolling = false; showRoll = true;
        Play(sLand);
        yield return Wait(0.35f / Spd);
        camOv = CamOv.None;
    }

    IEnumerator MoveFlow(Pl p, int r)
    {
        int target = p.pos + r;
        if (target > 100)
        {
            if (exactRoll) { Say(p, "Need exact roll!"); yield break; }
            target = 100;
        }
        p.anim = 1;
        while (p.pos < target)
        {
            yield return Hop(p, TilePos(p.pos + 1) + p.offset, 0.26f / Spd, 0.45f);
            p.pos++;
        }
        p.anim = 0;
        if (p.pos >= 100) yield break;
        Jmp j;
        if (jumps.TryGetValue(p.pos, out j))
        {
            activeJmp = j;
            if (j.snake) yield return SnakeFlow(p, j); else yield return LadderFlow(p, j);
        }
    }

    IEnumerator Hop(Pl p, Vector3 to, float dur, float arc)
    {
        Vector3 from = p.root.position;
        Vector3 d = to - from; d.y = 0;
        if (d.sqrMagnitude > 0.001f) p.root.rotation = Quaternion.LookRotation(d.normalized);
        float t = 0f; Play(sHop);
        while (t < 1f)
        {
            t += Time.deltaTime / dur;
            float k = Mathf.Clamp01(t);
            p.root.position = Vector3.Lerp(from, to, k) + Vector3.up * arc * 4f * k * (1f - k);
            yield return null;
        }
        p.root.position = to;
    }

    IEnumerator LadderFlow(Pl p, Jmp j)
    {
        camOv = autoCam ? CamOv.Ladder : CamOv.None;
        Say(p, Line(p, 0));
        yield return Wait(0.3f / Spd);
        p.anim = 4; Play(sLadder); j.glowTarget = 1.5f;
        float dur = 1.7f / Spd, t = 0f, nextSp = 0f;
        while (t < 1f)
        {
            t += Time.deltaTime / dur;
            float k = Mathf.Clamp01(t);
            Vector3 pt = LadPt(j, k) + Vector3.up * 0.05f + p.offset * 0.3f;
            p.root.position = pt;
            Vector3 dd = LadPt(j, Mathf.Min(1f, k + 0.05f)) - LadPt(j, k); dd.y = 0;
            if (dd.sqrMagnitude > 1e-4f) p.root.rotation = Quaternion.LookRotation(dd);
            nextSp -= Time.deltaTime;
            if (nextSp <= 0f) { nextSp = 0.18f; Burst(pt, 0, 6, 2f, 0.7f, -1.5f, 0.09f); }
            yield return null;
        }
        p.anim = 0;
        yield return Hop(p, TilePos(j.to) + p.offset, 0.4f / Spd, 0.6f);
        p.pos = j.to; p.ladders++; Inc("ladders"); Inc("d_ladder");
        Log(p.name + " climbed " + j.from + " > " + j.to);
        p.anim = 2; Burst(p.root.position + Vector3.up, 0, 25, 3f, 1f, -3f, 0.1f);
        yield return Wait(0.7f / Spd);
        p.anim = 0; j.glowTarget = 0f;
    }

    IEnumerator SnakeFlow(Pl p, Jmp j)
    {
        camOv = autoCam ? CamOv.Snake : CamOv.None;
        yield return Wait(0.3f / Spd);
        Play(sSnake); Vibe();
        float t = 0f;
        while (t < 1f)
        {
            t += Time.deltaTime / (0.5f / Spd);
            float k = Mathf.Clamp01(t);
            if (j.jaw != null) j.jaw.localRotation = Quaternion.Euler(40f * k, 0, 0);
            if (j.headT != null) j.headT.localScale = Vector3.one * (1f + 0.3f * k);
            yield return null;
        }
        p.anim = 3; Say(p, Line(p, 1));
        yield return Hop(p, j.path[0] + Vector3.up * 0.1f, 0.25f / Spd, 0.2f);
        float L = j.path.Length - 1; t = 0f; float dur = 1.6f / Spd;
        while (t < 1f)
        {
            t += Time.deltaTime / dur;
            float f = Mathf.Clamp01(t) * L;
            int i0 = Mathf.Min((int)f, j.path.Length - 2);
            p.root.position = Vector3.Lerp(j.path[i0], j.path[i0 + 1], f - i0) + Vector3.up * 0.15f;
            p.root.Rotate(0, 540f * Time.deltaTime, 0);
            yield return null;
        }
        if (j.jaw != null) j.jaw.localRotation = Quaternion.identity;
        if (j.headT != null) j.headT.localScale = Vector3.one;
        yield return Hop(p, TilePos(j.to) + p.offset, 0.3f / Spd, 0.3f);
        p.pos = j.to; p.snakes++; Inc("snakes");
        Log(p.name + " bitten " + j.from + " > " + j.to);
        yield return Wait(0.7f / Spd);
        p.anim = 0;
    }

    // ---------- finish ----------
    IEnumerator EndMatch(Pl w)
    {
        winner = w; matchOver = true; waitRoll = false;
        w.pos = 100; w.anim = 2; camOv = CamOv.Victory;
        foreach (var o in players) if (o != w && !o.eliminated) o.anim = 3;
        Play(sWin); Say(w, Line(w, 2));
        BuildTrophy(w);
        Time.timeScale = 0.35f;
        StartCoroutine(Celebrate(w));

        finalOrder = new List<Pl>(players);
        finalOrder.Sort((a, b) => b.pos.CompareTo(a.pos));
        finalOrder.Remove(w); finalOrder.Insert(0, w);
        int[] pts = { 4, 2, 1, 0 };
        for (int i = 0; i < finalOrder.Count; i++) finalOrder[i].points += pts[Mathf.Min(i, 3)];

        Pl me = players[0].human ? players[0] : null;
        if (w.human) { rewardCoins = 50 + 10 * (players.Count - 1); rewardXp = 60; }
        else if (me != null) { rewardCoins = 10; rewardXp = 20; }
        else { rewardCoins = 5; rewardXp = 10; }
        if (mode == 1) rewardCoins = (int)(rewardCoins * 0.8f);
        if (mode == 6) rewardCoins = (int)(rewardCoins * 1.5f);
        resultNote = "";
        if (mode == 2 && me != null)
        {
            if (w == me && me.rolls <= 30) { rewardCoins += 100; resultNote = "Challenge complete! +100 bonus"; }
            else resultNote = "Challenge failed (win within 30 rolls)";
        }
        if (mode == 3)
        {
            if (tourRound < 3) resultNote = "Round " + tourRound + " of 3 finished";
            else
            {
                Pl champ = players[0];
                foreach (var p in players) if (p.points > champ.points) champ = p;
                resultNote = "TOURNAMENT CHAMPION: " + champ.name + " (" + champ.points + " pts)";
                rewardCoins += 100;
            }
        }
        Coins += rewardCoins; Xp += rewardXp;
        Inc("games"); Inc("d_play");
        if (w.human) { Inc("wins"); Inc("d_win"); Inc("w_win"); }
        string rec = PlayerPrefs.GetString("recent", "");
        var parts = new List<string>(rec.Length > 0 ? rec.Split(';') : new string[0]);
        parts.Insert(0, w.name); if (parts.Count > 8) parts.RemoveRange(8, parts.Count - 8);
        PlayerPrefs.SetString("recent", string.Join(";", parts.ToArray()));
        PlayerPrefs.Save();

        yield return new WaitForSecondsRealtime(1.4f);
        Time.timeScale = 1f;
        yield return new WaitForSecondsRealtime(2.5f);
        showResult = true; resultT = 0f;
    }

    IEnumerator Celebrate(Pl w)
    {
        for (int i = 0; i < 10; i++)
        {
            Burst(w.root.position + Vector3.up * 4f, -1, 40, 3.5f, 4.5f, -3.2f, 0.13f);
            Burst(new Vector3(Random.Range(-4f, 4f), Random.Range(3.5f, 6.5f), Random.Range(-3f, 4f)), -1, 40, 4f, 1.4f, -2.5f, 0.1f);
            yield return Wait(0.6f);
        }
    }

    void NextRound() { tourRound++; StartMatch(true); }
}
