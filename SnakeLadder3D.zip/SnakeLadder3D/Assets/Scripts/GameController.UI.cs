using System.Collections.Generic;
using UnityEngine;

public partial class GameController
{
    float sc = 1f, W = 960f;
    GUIStyle ls, tf;
    static readonly Color Gold = new Color(1f, .82f, .2f);
    static readonly Color Panel = new Color(.04f, .06f, .16f, .78f);
    static readonly Color Blue = new Color(.15f, .45f, .95f);
    static readonly Color Green = new Color(.15f, .7f, .3f);
    static readonly Color Red = new Color(.85f, .2f, .2f);
    static readonly Color Purple = new Color(.5f, .25f, .85f);
    static readonly Color Grey = new Color(.3f, .33f, .45f);

    Rect R(float x, float y, float w, float h) { return new Rect(x * sc, y * sc, w * sc, h * sc); }

    void Box(float x, float y, float w, float h, Color c)
    {
        var o = GUI.color; GUI.color = c; GUI.DrawTexture(R(x, y, w, h), Texture2D.whiteTexture); GUI.color = o;
    }

    void Txt(float x, float y, float w, float h, string t, int fs, Color c, TextAnchor a = TextAnchor.MiddleCenter)
    {
        if (ls == null) { ls = new GUIStyle(); ls.fontStyle = FontStyle.Bold; ls.clipping = TextClipping.Overflow; }
        ls.fontSize = Mathf.Max(6, (int)(fs * sc)); ls.alignment = a;
        ls.normal.textColor = new Color(0, 0, 0, 0.6f * c.a);
        GUI.Label(R(x + 1.2f, y + 1.2f, w, h), t, ls);
        ls.normal.textColor = c;
        GUI.Label(R(x, y, w, h), t, ls);
    }

    bool Btn(float x, float y, float w, float h, string t, Color c, int fs = 20, bool enabled = true)
    {
        Color cc = enabled ? c : new Color(.3f, .3f, .35f, 1f);
        Box(x, y, w, h, new Color(0, 0, 0, .5f));
        Box(x + 1.5f, y + 1.5f, w - 3f, h - 3f, cc);
        Box(x + 1.5f, y + 1.5f, w - 3f, h * 0.45f, new Color(1, 1, 1, .14f));
        Txt(x, y, w, h, t, fs, Color.white);
        bool hit = GUI.Button(R(x, y, w, h), GUIContent.none, GUIStyle.none);
        if (hit && enabled) { Play(sClick); return true; }
        return false;
    }

    bool Tog(float x, float y, float w, float h, string label, bool v, int fs = 13)
    {
        return Btn(x, y, w, h, label + ": " + (v ? "ON" : "OFF"), v ? Green : Grey, fs);
    }

    int Choice(float x, float y, float colW, string label, string[] opts, int sel)
    {
        Txt(x, y, 120, 36, label, 15, Color.white, TextAnchor.MiddleLeft);
        float bw = (colW - 125f) / opts.Length;
        for (int i = 0; i < opts.Length; i++)
            if (Btn(x + 120 + i * bw, y, bw - 4, 36, opts[i], i == sel ? Gold * 0.9f : Grey, 13)) sel = i;
        return sel;
    }

    string Fmt(float t) { int s = (int)t; return (s / 60).ToString("00") + ":" + (s % 60).ToString("00"); }

    void OnGUI()
    {
        sc = Screen.height / 540f; W = Screen.width / sc;
        switch (page)
        {
            case Page.Home: GHome(); break;
            case Page.Setup: GSetup(); break;
            case Page.Game: GGame(); break;
            case Page.Shop: GShop(); break;
            case Page.Rewards: GRewards(); break;
            case Page.Stats: GStats(); break;
            case Page.Settings: GSettings(); break;
        }
    }

    void TopBar(string title)
    {
        Box(0, 0, W, 48, new Color(0, 0, 0, .55f));
        if (Btn(8, 6, 90, 36, "< BACK", Grey, 15)) page = Page.Home;
        Txt(0, 0, W, 48, title, 24, Gold);
        Txt(W - 330, 0, 320, 48, "Coins " + Coins + "   Lv " + Level, 16, Gold, TextAnchor.MiddleRight);
    }

    // ---------- HOME ----------
    void GHome()
    {
        Box(0, 0, W, 48, new Color(0, 0, 0, .45f));
        Txt(12, 0, 400, 48, "Coins " + Coins + "    Level " + Level + "    XP " + Xp, 17, Gold, TextAnchor.MiddleLeft);
        float pulse = 1f + 0.04f * Mathf.Sin(Time.time * 2f);
        Txt(10, 90, W * 0.5f, 90, "SNAKE &", (int)(52 * pulse), Color.Lerp(Gold, Color.white, 0.5f + 0.5f * Mathf.Sin(Time.time)));
        Txt(10, 150, W * 0.5f, 90, "LADDER 3D", (int)(52 * pulse), Gold);
        Txt(10, 225, W * 0.5f, 40, "ULTIMATE EDITION", 22, Color.white);
        float x0 = W - 440f;
        string[] names = { "PLAY NOW", "PLAY WITH BOTS", "LOCAL MULTIPLAYER", "TOURNAMENT", "PREMIUM MODES", "DICE COLLECTION", "DAILY REWARDS", "STATS / LEADERBOARD", "SETTINGS" };
        Color[] cols = { Green, Blue, Purple, Red, Gold * 0.9f, Blue, Green, Purple, Grey };
        for (int i = 0; i < names.Length; i++)
        {
            float x = x0 + (i % 2) * 215f, y = 62f + (i / 2) * 66f;
            if (!Btn(x, y, 205, 56, names[i], cols[i], 15)) continue;
            switch (i)
            {
                case 0: numPlayers = 2; numHumans = 1; mode = 0; OpenSetup(); break;
                case 1: numPlayers = 4; numHumans = 1; mode = 0; OpenSetup(); break;
                case 2: numPlayers = 2; numHumans = 2; mode = 0; OpenSetup(); break;
                case 3: numPlayers = 4; numHumans = 1; mode = 3; OpenSetup(); break;
                case 4: numPlayers = 4; numHumans = 1; mode = 9; OpenSetup(); break;
                case 5: page = Page.Shop; break;
                case 6: page = Page.Rewards; break;
                case 7: page = Page.Stats; break;
                case 8: page = Page.Settings; break;
            }
        }
        if (Btn(W - 440, 62 + 5 * 66, 205, 56, "EXIT", Red, 15)) Application.Quit();
    }

    // ---------- SETUP / LOBBY ----------
    void GSetup()
    {
        Box(10, 54, 430, 470, Panel);
        Txt(20, 58, 300, 24, "3D LOBBY", 16, Gold, TextAnchor.MiddleLeft);
        Txt(20, 84, 90, 34, "PLAYERS", 14, Color.white, TextAnchor.MiddleLeft);
        for (int i = 0; i < 3; i++)
            if (Btn(115 + i * 70, 84, 62, 34, (i + 2).ToString(), numPlayers == i + 2 ? Gold * 0.9f : Grey, 16))
            { numPlayers = i + 2; if (numHumans > numPlayers) numHumans = numPlayers; RebuildLobby(); }
        Txt(20, 126, 90, 34, "HUMANS", 14, Color.white, TextAnchor.MiddleLeft);
        for (int i = 0; i <= 4; i++)
            if (Btn(115 + i * 58, 126, 54, 34, i.ToString(), numHumans == i ? Gold * 0.9f : Grey, 16, i <= numPlayers))
            { numHumans = i; RebuildLobby(); }
        Txt(20, 168, 300, 22, "MODE", 14, Gold, TextAnchor.MiddleLeft);
        for (int i = 0; i < 10; i++)
            if (Btn(20 + (i % 5) * 82, 192 + (i / 5) * 36, 78, 32, GameData.Modes[i], mode == i ? Gold * 0.9f : Blue, 11))
            { mode = i; RebuildLobby(); }
        Txt(20, 268, 300, 22, "WORLD", 14, Gold, TextAnchor.MiddleLeft);
        for (int i = 0; i < 8; i++)
            if (Btn(20 + (i % 4) * 102, 292 + (i / 4) * 36, 98, 32, GameData.Worlds[i], world == i ? Gold * 0.9f : Purple, 12))
            { world = i; RebuildLobby(); }
        if (Tog(20, 372, 130, 34, "Exact roll", exactRoll)) exactRoll = !exactRoll;
        if (Tog(156, 372, 130, 34, "6 = again", sixAgain)) sixAgain = !sixAgain;
        if (Tog(292, 372, 138, 34, "Auto cam", autoCam)) autoCam = !autoCam;

        if (tf == null) { tf = new GUIStyle(GUI.skin.textField); }
        tf.fontSize = Mathf.Max(8, (int)(16 * sc));
        Txt(20, 414, 60, 34, "NAME", 13, Color.white, TextAnchor.MiddleLeft);
        string nn = GUI.TextField(R(80, 414, 170, 34), p1Name, 12, tf);
        if (nn != p1Name)
        {
            p1Name = nn; PlayerPrefs.SetString("pname", nn);
            if (players.Count > 0 && players[0].human) players[0].name = string.IsNullOrEmpty(nn) ? "Player" : nn;
        }
        if (Btn(258, 414, 172, 34, "Hat: " + GameData.Hats[p1Hat], Purple, 13))
        {
            p1Hat = (p1Hat + 1) % GameData.Hats.Length; PlayerPrefs.SetInt("phat", p1Hat); RebuildLobby();
        }
        if (Btn(20, 468, 120, 44, "< BACK", Grey, 16)) page = Page.Home;

        Box(W - 380, 54, 370, 92, Panel);
        Txt(W - 370, 58, 350, 28, GameData.Modes[mode] + "  -  " + GameData.Worlds[world], 17, Gold, TextAnchor.MiddleLeft);
        Txt(W - 370, 88, 350, 54, GameData.ModeDesc[mode], 13, Color.white, TextAnchor.UpperLeft);
        for (int i = 0; i < players.Count; i++)
            if (players[i].root != null)
            {
                Vector3 sp = cam.WorldToScreenPoint(players[i].root.position + Vector3.up * 1.9f);
                if (sp.z > 0) Txt(sp.x / sc - 70, (Screen.height - sp.y) / sc - 12, 140, 24, players[i].name + (players[i].human ? "" : " (" + players[i].persona + ")"), 13, Color.white);
            }
        float pl = 1f + 0.05f * Mathf.Sin(Time.time * 4f);
        if (Btn(W - 260, 440, 240 * pl, 80, "START MATCH", Green, 24)) StartMatch(false);
    }

    // ---------- GAME HUD ----------
    void GGame()
    {
        if (Event.current.type == EventType.Repaint) DrawWorldLabels();
        // player cards
        var ranked = new List<Pl>(players); ranked.Sort((a, b) => b.pos.CompareTo(a.pos));
        for (int i = 0; i < players.Count; i++)
        {
            var p = players[i]; float y = 58 + i * 66;
            bool isCur = (i == cur && !matchOver);
            Box(8, y, 200, 60, isCur ? Gold : new Color(0, 0, 0, .6f));
            Box(10, y + 2, 196, 56, p.eliminated ? new Color(.2f, .2f, .2f, .9f) : new Color(p.color.r * .5f, p.color.g * .5f, p.color.b * .5f, .9f));
            Box(10, y + 2, 10, 56, p.color);
            Txt(24, y + 4, 180, 22, p.name + (p.human ? "" : " [" + p.persona + "]"), 13, Color.white, TextAnchor.MiddleLeft);
            Txt(24, y + 26, 180, 18, p.eliminated ? "OUT" : "Tile " + p.pos + "  (" + (100 - p.pos) + " to go)", 12, Color.white, TextAnchor.MiddleLeft);
            Txt(24, y + 42, 180, 16, "Rank " + (ranked.IndexOf(p) + 1) + (mode == 3 ? "   Pts " + p.points : ""), 11, Gold, TextAnchor.MiddleLeft);
        }
        // top
        Box(W / 2 - 170, 4, 340, 48, new Color(0, 0, 0, .55f));
        Txt(W / 2 - 170, 4, 340, 24, GameData.Modes[mode] + (mode == 3 ? "  Round " + tourRound + "/3" : "") + "   " + Fmt(matchTime), 14, Gold);
        if (!matchOver && cur < players.Count) Txt(W / 2 - 170, 26, 340, 24, players[cur].name + "'s turn", 15, Color.white);
        if (Btn(W - 100, 6, 92, 40, "PAUSE", Grey, 15, !matchOver)) Pause(true);
        // right panel
        Box(W - 198, 56, 190, 250, Panel);
        Txt(W - 190, 58, 180, 22, "TURN HISTORY", 13, Gold);
        for (int i = 0; i < history.Count && i < 8; i++)
            Txt(W - 190, 82 + i * 27, 180, 26, history[i], 11, new Color(1, 1, 1, 1f - i * 0.09f), TextAnchor.MiddleLeft);
        CamMode cm = (CamMode)Gi("cam", 0);
        if (Btn(W - 198, 314, 100, 36, "CAM: " + cm, Blue, 13)) PlayerPrefs.SetInt("cam", (Gi("cam", 0) + 1) % 4);
        if (Btn(W - 94, 314, 42, 36, "+", Blue, 20)) zoom = Mathf.Max(0.5f, zoom - 0.15f);
        if (Btn(W - 48, 314, 40, 36, "-", Blue, 20)) zoom = Mathf.Min(1.8f, zoom + 0.15f);
        if (Btn(W - 198, 356, 92, 34, "Music " + (MusicOn ? "ON" : "OFF"), MusicOn ? Green : Grey, 12)) { PlayerPrefs.SetInt("musicOn", MusicOn ? 0 : 1); ApplyAudio(); }
        if (Btn(W - 100, 356, 92, 34, "SFX " + (SfxOn ? "ON" : "OFF"), SfxOn ? Green : Grey, 12)) PlayerPrefs.SetInt("sfxOn", SfxOn ? 0 : 1);
        Txt(W - 198, 396, 190, 22, "Drag: rotate   Pinch: zoom", 10, new Color(1, 1, 1, .6f));
        // roll button
        bool left = Gi("hand", 1) == 0;
        float rx = left ? 8f : W - 198f;
        if (!matchOver && cur < players.Count && !paused)
        {
            var cp = players[cur];
            if (cp.human && waitRoll)
            {
                float pl = 1f + 0.05f * Mathf.Sin(Time.time * 6f);
                if (Btn(rx, 450, 190, 70 * pl, "ROLL DICE", Green, 24)) rollPressed = true;
            }
            else Txt(rx, 450, 190, 70, cp.human ? "Rolling..." : cp.name + " is playing", 15, Color.white);
        }
        // dice result
        if (showRoll && dice != null && !matchOver)
        {
            Vector3 sp = cam.WorldToScreenPoint(DicePos + Vector3.up * 1.2f);
            if (sp.z > 0) Txt(sp.x / sc - 40, (Screen.height - sp.y) / sc - 30, 80, 60, "+" + lastRoll, 40, Gold);
        }
        if (paused) GPause();
        if (showResult) GResult();
    }

    void DrawWorldLabels()
    {
        for (int n = 1; n <= 100; n++)
        {
            Vector3 sp = cam.WorldToScreenPoint(TilePos(n) + new Vector3(-0.3f, 0.02f, -0.3f));
            if (sp.z <= 0) continue;
            Txt(sp.x / sc - 15, (Screen.height - sp.y) / sc - 9, 30, 18, n.ToString(), 11, new Color(0, 0, 0, .75f));
        }
        foreach (var p in players)
        {
            if (p.root == null || Time.time > p.bubbleUntil || string.IsNullOrEmpty(p.bubble)) continue;
            Vector3 sp = cam.WorldToScreenPoint(p.root.position + Vector3.up * 2.3f);
            if (sp.z <= 0) continue;
            float bx = sp.x / sc, by = (Screen.height - sp.y) / sc;
            Box(bx - 80, by - 14, 160, 28, new Color(1, 1, 1, .9f));
            Txt(bx - 80, by - 14, 160, 28, p.bubble, 12, new Color(.1f, .1f, .2f));
        }
    }

    void GPause()
    {
        Box(0, 0, W, 540, new Color(0, 0, 0, .65f));
        Txt(0, 90, W, 50, "PAUSED", 40, Gold);
        float cx = W / 2 - 110;
        if (Btn(cx, 160, 220, 50, "RESUME", Green, 20)) Pause(false);
        if (Btn(cx, 220, 220, 50, "RESTART", Blue, 20)) StartMatch(false);
        if (Btn(cx, 280, 220, 50, "HOME", Red, 20)) ToHome();
        if (Btn(cx, 340, 106, 44, "Music " + (MusicOn ? "ON" : "OFF"), MusicOn ? Green : Grey, 13)) { PlayerPrefs.SetInt("musicOn", MusicOn ? 0 : 1); ApplyAudio(); }
        if (Btn(cx + 114, 340, 106, 44, "SFX " + (SfxOn ? "ON" : "OFF"), SfxOn ? Green : Grey, 13)) PlayerPrefs.SetInt("sfxOn", SfxOn ? 0 : 1);
    }

    void GResult()
    {
        Box(0, 0, W, 540, new Color(0, 0, 0, .55f * resultT));
        float x = W / 2 - 300;
        Box(x, 30, 600, 480, new Color(.04f, .06f, .16f, .92f * resultT));
        Color g = new Color(Gold.r, Gold.g, Gold.b, resultT);
        Txt(x, 38, 600, 50, "WINNER: " + (winner != null ? winner.name : ""), 32, g);
        if (resultNote.Length > 0) Txt(x, 86, 600, 26, resultNote, 15, new Color(1, 1, 1, resultT));
        Txt(x + 10, 116, 40, 22, "#", 12, g); Txt(x + 40, 116, 150, 22, "PLAYER", 12, g, TextAnchor.MiddleLeft);
        Txt(x + 200, 116, 70, 22, "TILE", 12, g); Txt(x + 270, 116, 70, 22, "ROLLS", 12, g);
        Txt(x + 340, 116, 80, 22, "LADDERS", 12, g); Txt(x + 420, 116, 80, 22, "SNAKES", 12, g); Txt(x + 500, 116, 80, 22, "PTS", 12, g);
        for (int i = 0; i < finalOrder.Count; i++)
        {
            var p = finalOrder[i]; float y = 142 + i * 40;
            Box(x + 8, y, 584, 36, new Color(p.color.r * .5f, p.color.g * .5f, p.color.b * .5f, .85f * resultT));
            Color w = new Color(1, 1, 1, resultT);
            Txt(x + 10, y, 40, 36, (i + 1).ToString(), 15, w);
            Txt(x + 40, y, 160, 36, p.name, 15, w, TextAnchor.MiddleLeft);
            Txt(x + 200, y, 70, 36, p.pos.ToString(), 14, w); Txt(x + 270, y, 70, 36, p.rolls.ToString(), 14, w);
            Txt(x + 340, y, 80, 36, p.ladders.ToString(), 14, w); Txt(x + 420, y, 80, 36, p.snakes.ToString(), 14, w);
            Txt(x + 500, y, 80, 36, p.points.ToString(), 14, w);
        }
        Txt(x, 312, 600, 26, "Time " + Fmt(matchTime), 14, new Color(1, 1, 1, resultT));
        Txt(x, 342, 600, 36, "+" + rewardCoins + " coins    +" + rewardXp + " XP", 26, g);
        bool nextRound = mode == 3 && tourRound < 3;
        if (nextRound) { if (Btn(x + 40, 420, 250, 56, "NEXT ROUND", Green, 22)) NextRound(); }
        else if (Btn(x + 40, 420, 250, 56, "REMATCH", Green, 22)) StartMatch(false);
        if (Btn(x + 310, 420, 250, 56, "HOME", Red, 22)) ToHome();
    }

    // ---------- SHOP ----------
    void GShop()
    {
        Box(0, 0, W, 540, new Color(0, 0, 0, .55f));
        TopBar("DICE COLLECTION");
        int own = Gi("diceOwn", 1), sel = Gi("dice", 0);
        float cw = (W - 50f) / 4f;
        for (int i = 0; i < GameData.DiceNames.Length; i++)
        {
            float x = 10 + (i % 4) * (cw + 10f) / 1f * 0.97f, y = 62 + (i / 4) * 150;
            x = 10 + (i % 4) * (cw + 10f);
            bool owned = (own & (1 << i)) != 0;
            Box(x, y, cw, 140, Panel);
            Box(x + cw / 2 - 30, y + 12, 60, 60, GameData.DiceColors[i]);
            Box(x + cw / 2 - 30, y + 12, 60, 8, new Color(1, 1, 1, .25f));
            Txt(x, y + 76, cw, 22, GameData.DiceNames[i], 15, Color.white);
            string lab = i == sel ? "SELECTED" : (owned ? "USE" : GameData.DicePrice[i] + " coins");
            Color bc = i == sel ? Gold * 0.9f : (owned ? Blue : (Coins >= GameData.DicePrice[i] ? Green : Grey));
            if (Btn(x + 10, y + 100, cw - 20, 34, lab, bc, 14))
            {
                if (owned) { PlayerPrefs.SetInt("dice", i); RefreshDiceSkin(); }
                else if (Coins >= GameData.DicePrice[i])
                {
                    Coins -= GameData.DicePrice[i]; PlayerPrefs.SetInt("diceOwn", own | (1 << i)); PlayerPrefs.SetInt("dice", i);
                    PlayerPrefs.Save(); RefreshDiceSkin();
                }
            }
        }
    }

    // ---------- REWARDS ----------
    static readonly string[] mLabel = { "Play 3 matches", "Climb 5 ladders", "Win 1 match", "Weekly: win 5 matches" };
    static readonly string[] mKey = { "d_play", "d_ladder", "d_win", "w_win" };
    static readonly int[] mTarget = { 3, 5, 1, 5 };
    static readonly int[] mRew = { 40, 40, 60, 250 };
    static readonly string[] aLabel = { "First Win", "Champion (10 wins)", "Ladder Lover (50)", "Snake Survivor (25 bites)", "Veteran (25 games)", "Reach Level 5" };
    static readonly string[] aKey = { "wins", "wins", "ladders", "snakes", "games", "level" };
    static readonly int[] aTarget = { 1, 10, 50, 25, 25, 5 };
    static readonly int[] aRew = { 50, 200, 100, 100, 150, 150 };

    int StatVal(string k) { return k == "level" ? Level : Gi(k, 0); }

    void GRewards()
    {
        Box(0, 0, W, 540, new Color(0, 0, 0, .55f));
        TopBar("REWARDS");
        string last = PlayerPrefs.GetString("lastDaily", "");
        bool can = last != Today();
        int streak = Gi("streak", 0);
        Box(10, 58, W - 20, 70, Panel);
        Txt(20, 58, 500, 70, "Daily reward - streak " + streak + " day(s)", 18, Gold, TextAnchor.MiddleLeft);
        if (Btn(W - 230, 70, 210, 46, can ? "CLAIM TODAY" : "CLAIMED", can ? Green : Grey, 18, can))
        {
            string y = System.DateTime.Now.AddDays(-1).ToString("yyyyMMdd");
            streak = (last == y) ? streak + 1 : 1;
            PlayerPrefs.SetInt("streak", streak); PlayerPrefs.SetString("lastDaily", Today());
            Coins += 25 + Mathf.Min(streak, 7) * 15; Xp += 20; PlayerPrefs.Save();
        }
        Txt(10, 134, 400, 24, "DAILY MISSIONS / WEEKLY CHALLENGE", 14, Gold, TextAnchor.MiddleLeft);
        for (int i = 0; i < 4; i++)
        {
            float y = 160 + i * 52; int v = Mathf.Min(Gi(mKey[i], 0), mTarget[i]); bool done = v >= mTarget[i]; bool claimed = Gi("c_" + mKey[i], 0) == 1;
            Box(10, y, W - 20, 46, Panel);
            Txt(20, y, 360, 46, mLabel[i] + "  (" + v + "/" + mTarget[i] + ")", 15, Color.white, TextAnchor.MiddleLeft);
            if (Btn(W - 230, y + 4, 210, 38, claimed ? "CLAIMED" : "CLAIM +" + mRew[i], done && !claimed ? Green : Grey, 14, done && !claimed))
            { PlayerPrefs.SetInt("c_" + mKey[i], 1); Coins += mRew[i]; PlayerPrefs.Save(); }
        }
        Txt(10, 372, 400, 24, "ACHIEVEMENTS", 14, Gold, TextAnchor.MiddleLeft);
        for (int i = 0; i < 6; i++)
        {
            float x = 10 + (i % 2) * (W / 2 - 5), y = 398 + (i / 2) * 44; float hw = W / 2 - 15;
            int v = Mathf.Min(StatVal(aKey[i]), aTarget[i]); bool done = v >= aTarget[i]; bool claimed = Gi("ac" + i, 0) == 1;
            Box(x, y, hw, 40, Panel);
            Txt(x + 8, y, hw - 130, 40, aLabel[i] + " " + v + "/" + aTarget[i], 12, Color.white, TextAnchor.MiddleLeft);
            if (Btn(x + hw - 120, y + 4, 114, 32, claimed ? "CLAIMED" : "+" + aRew[i], done && !claimed ? Green : Grey, 12, done && !claimed))
            { PlayerPrefs.SetInt("ac" + i, 1); Coins += aRew[i]; PlayerPrefs.Save(); }
        }
    }

    // ---------- STATS ----------
    void GStats()
    {
        Box(0, 0, W, 540, new Color(0, 0, 0, .55f));
        TopBar("STATS / LEADERBOARD");
        int g = Gi("games", 0), w = Gi("wins", 0);
        Box(10, 58, 420, 300, Panel);
        string[] lines = { "Level " + Level + "   (XP " + Xp + ")", "Coins " + Coins, "Games played " + g, "Wins " + w, "Win rate " + (g > 0 ? (100 * w / g) : 0) + "%", "Ladders climbed " + Gi("ladders", 0), "Snake bites " + Gi("snakes", 0) };
        for (int i = 0; i < lines.Length; i++) Txt(24, 66 + i * 38, 400, 34, lines[i], 18, Color.white, TextAnchor.MiddleLeft);
        Box(450, 58, W - 460, 300, Panel);
        Txt(460, 62, 300, 28, "RECENT WINNERS", 16, Gold, TextAnchor.MiddleLeft);
        string rec = PlayerPrefs.GetString("recent", "");
        string[] names = rec.Length > 0 ? rec.Split(';') : new string[0];
        for (int i = 0; i < names.Length; i++) Txt(470, 96 + i * 30, 300, 28, (i + 1) + ". " + names[i], 16, Color.white, TextAnchor.MiddleLeft);
    }

    // ---------- SETTINGS ----------
    static readonly string[] offOn = { "Off", "On" };
    static readonly string[] vol = { "0%", "25%", "50%", "75%", "100%" };
    static readonly int[] fpsVals = { 30, 60, 90 };
    static readonly float[] animVals = { 0.75f, 1f, 1.5f, 2f };

    void GSettings()
    {
        Box(0, 0, W, 540, new Color(0, 0, 0, .55f));
        TopBar("SETTINGS");
        float cw = W / 2 - 20, x1 = 10, x2 = W / 2 + 10, y = 62;
        int v;
        v = Choice(x1, y, cw, "Music", offOn, Gi("musicOn", 1)); if (v != Gi("musicOn", 1)) { PlayerPrefs.SetInt("musicOn", v); ApplyAudio(); }
        y += 48;
        v = Choice(x1, y, cw, "Sound FX", offOn, Gi("sfxOn", 1)); if (v != Gi("sfxOn", 1)) PlayerPrefs.SetInt("sfxOn", v);
        y += 48;
        v = Choice(x1, y, cw, "Music vol", vol, Mathf.RoundToInt(MusVol * 4f)); if (v != Mathf.RoundToInt(MusVol * 4f)) { PlayerPrefs.SetFloat("musVol", v / 4f); ApplyAudio(); }
        y += 48;
        v = Choice(x1, y, cw, "SFX vol", vol, Mathf.RoundToInt(SfxVol * 4f)); if (v != Mathf.RoundToInt(SfxVol * 4f)) PlayerPrefs.SetFloat("sfxVol", v / 4f);
        y += 48;
        v = Choice(x1, y, cw, "Vibration", offOn, Gi("vib", 1)); if (v != Gi("vib", 1)) PlayerPrefs.SetInt("vib", v);
        y += 48;
        v = Choice(x1, y, cw, "Hand", new[] { "Left", "Right" }, Gi("hand", 1)); if (v != Gi("hand", 1)) PlayerPrefs.SetInt("hand", v);

        y = 62;
        v = Choice(x2, y, cw, "Graphics", new[] { "Low", "Med", "High", "Ultra" }, Gi("gfx", 2)); if (v != Gi("gfx", 2)) { PlayerPrefs.SetInt("gfx", v); ApplyQuality(); }
        y += 48;
        int fi = System.Array.IndexOf(fpsVals, Gi("fps", 60)); if (fi < 0) fi = 1;
        v = Choice(x2, y, cw, "FPS", new[] { "30", "60", "90" }, fi); if (v != fi) { PlayerPrefs.SetInt("fps", fpsVals[v]); ApplyQuality(); }
        y += 48;
        int ai = System.Array.IndexOf(animVals, PlayerPrefs.GetFloat("anim", 1f)); if (ai < 0) ai = 1;
        v = Choice(x2, y, cw, "Anim speed", new[] { "0.75x", "1x", "1.5x", "2x" }, ai); if (v != ai) PlayerPrefs.SetFloat("anim", animVals[v]);
        y += 48;
        v = Choice(x2, y, cw, "Camera", new[] { "Iso", "Top", "Follow", "Cine" }, Gi("cam", 0)); if (v != Gi("cam", 0)) PlayerPrefs.SetInt("cam", v);
        y += 48;
        v = Choice(x2, y, cw, "Perspective", new[] { "Narrow", "Normal", "Wide" }, Gi("fov", 1)); if (v != Gi("fov", 1)) PlayerPrefs.SetInt("fov", v);
        Txt(10, 420, W - 20, 60, "In a match: drag to rotate the camera, pinch (or +/-) to zoom, CAM button to switch views.", 14, new Color(1, 1, 1, .8f));
    }
}
