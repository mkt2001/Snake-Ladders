using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class GameBootstrap
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void Init()
    {
        if (Object.FindObjectOfType<GameController>() != null) return;
        new GameObject("SnakeLadder3D").AddComponent<GameController>();
    }
}

public partial class GameController : MonoBehaviour
{
    const float TOP = 0.2f;
    Page page = Page.Home;
    Camera cam; Transform worldRoot, fxRoot; Shader shader; Light sun;
    List<Pl> players = new List<Pl>();
    Dictionary<int, Jmp> jumps = new Dictionary<int, Jmp>();
    List<Jmp> jumpList = new List<Jmp>();
    Theme th = new Theme();

    // setup
    int numPlayers = 2, numHumans = 1, mode = 0, world = 0;
    bool exactRoll, sixAgain = true, autoCam = true;
    string p1Name = "Player"; int p1Hat = 1;

    // match
    int cur, lastRoll = 1, roundNo, tourRound = 1;
    bool matchOver, rolling, waitRoll, rollPressed, paused, showResult, showRoll;
    float matchTime, resultT;
    List<string> history = new List<string>();
    Pl winner; int rewardCoins, rewardXp; string resultNote = "";
    List<Pl> finalOrder = new List<Pl>();
    CamOv camOv = CamOv.None; Jmp activeJmp;
    float zoom = 1f, manualYaw, manualPitch; bool dragging; Vector2 lastMouse;
    Vector3 camTP; float camDist = 16f, camPitch = 50f, camYaw;

    float Spd { get { return (mode == 1 ? 1.8f : 1f) * PlayerPrefs.GetFloat("anim", 1f); } }

    // ---------- prefs ----------
    int Coins { get { return PlayerPrefs.GetInt("coins", 100); } set { PlayerPrefs.SetInt("coins", value); } }
    int Xp { get { return PlayerPrefs.GetInt("xp", 0); } set { PlayerPrefs.SetInt("xp", value); } }
    int Level { get { return 1 + Xp / 150; } }
    int Gi(string k, int d) { return PlayerPrefs.GetInt(k, d); }
    void Inc(string k, int n = 1) { PlayerPrefs.SetInt(k, PlayerPrefs.GetInt(k, 0) + n); }
    string Today() { return System.DateTime.Now.ToString("yyyyMMdd"); }
    int WeekId() { return ((int)((System.DateTime.Now.Date - new System.DateTime(2024, 1, 1)).TotalDays)) / 7; }

    void CheckDay()
    {
        if (PlayerPrefs.GetString("mDate", "") != Today())
        {
            PlayerPrefs.SetString("mDate", Today());
            foreach (var k in new[] { "d_play", "d_ladder", "d_win", "c_d_play", "c_d_ladder", "c_d_win" }) PlayerPrefs.SetInt(k, 0);
        }
        if (PlayerPrefs.GetInt("wkId", -1) != WeekId())
        {
            PlayerPrefs.SetInt("wkId", WeekId());
            PlayerPrefs.SetInt("w_win", 0); PlayerPrefs.SetInt("c_w_win", 0);
        }
    }

    // ---------- helpers ----------
    static Color C(float r, float g, float b) { return new Color(r, g, b, 1f); }

    Material Mat(Color c, float gloss = 0.5f, float emis = 0f)
    {
        var m = new Material(shader);
        m.color = c;
        m.enableInstancing = true;
        if (shader.name == "Standard")
        {
            m.SetFloat("_Glossiness", gloss);
            if (emis > 0f) { m.EnableKeyword("_EMISSION"); m.SetColor("_EmissionColor", c * emis); }
        }
        return m;
    }

    GameObject Prim(PrimitiveType t, Transform par, Vector3 lp, Vector3 scl, Material m, string n = "p")
    {
        var g = GameObject.CreatePrimitive(t);
        g.name = n;
        var col = g.GetComponent<Collider>(); if (col != null) Destroy(col);
        g.transform.SetParent(par, false);
        g.transform.localPosition = lp;
        g.transform.localScale = scl;
        g.GetComponent<Renderer>().sharedMaterial = m;
        return g;
    }

    GameObject Bar(Transform par, Vector3 p, Vector3 q, float r, Material m)
    {
        var g = Prim(PrimitiveType.Cylinder, par, (p + q) * 0.5f, new Vector3(r * 2f, (q - p).magnitude * 0.5f, r * 2f), m, "Bar");
        g.transform.up = (q - p).normalized;
        return g;
    }

    Vector3 TilePos(int n)
    {
        if (n <= 0) return new Vector3(-4.5f, TOP, -6f);
        if (n > 100) n = 100;
        int r = (n - 1) / 10, c = (n - 1) % 10;
        if (r % 2 == 1) c = 9 - c;
        return new Vector3(c - 4.5f, TOP, r - 4.5f);
    }

    Vector3 DicePos { get { return new Vector3(7.4f, 0.5f, -1.5f); } }
    Vector3 LobbyPos(int i, int n) { return new Vector3((i - (n - 1) * 0.5f) * 1.8f, 0f, -7.5f); }

    // ---------- lifecycle ----------
    void Awake()
    {
        Screen.orientation = ScreenOrientation.LandscapeLeft;
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        shader = Shader.Find("Standard");
        if (shader == null) shader = Shader.Find("Legacy Shaders/Diffuse");
        if (shader == null) shader = Shader.Find("Sprites/Default");

        foreach (var c in FindObjectsOfType<Camera>()) Destroy(c.gameObject);
        var cg = new GameObject("MainCam"); cg.tag = "MainCamera";
        cam = cg.AddComponent<Camera>(); cg.AddComponent<AudioListener>();
        cam.clearFlags = CameraClearFlags.SolidColor; cam.nearClipPlane = 0.1f; cam.farClipPlane = 200f; cam.fieldOfView = 45f;
        fxRoot = new GameObject("FX").transform;

        p1Name = PlayerPrefs.GetString("pname", "Player");
        p1Hat = Gi("phat", 1);
        InitAudio();
        InitFxMats();
        CheckDay();
        ApplyQuality();
        ConfigurePlayers();
        BuildWorld(true);
    }

    void Update()
    {
        float dt = Time.deltaTime;
        if (page == Page.Game && !matchOver && !paused) matchTime += dt;
        if (showResult) resultT = Mathf.MoveTowards(resultT, 1f, Time.unscaledDeltaTime * 2f);
        AnimatePawns();
        AnimateWorld(dt);
        UpdateFx(dt);
        HandleInput();
        if (Input.GetKeyDown(KeyCode.Escape)) OnBack();
    }

    void OnApplicationPause(bool p) { if (p && page == Page.Game && !matchOver && !paused) Pause(true); }

    void OnBack()
    {
        if (page == Page.Game) { if (showResult) ToHome(); else Pause(!paused); }
        else if (page == Page.Home) Application.Quit();
        else page = Page.Home;
    }

    void Pause(bool b) { paused = b; Time.timeScale = b ? 0f : 1f; }

    void ApplyQuality()
    {
        int q = Gi("gfx", 2);
        QualitySettings.vSyncCount = 0;
        Application.targetFrameRate = Gi("fps", 60);
        QualitySettings.antiAliasing = q >= 3 ? 4 : (q == 2 ? 2 : 0);
        ApplyShadows();
    }

    void ApplyShadows()
    {
        int q = Gi("gfx", 2);
        QualitySettings.shadows = q == 0 ? ShadowQuality.Disable : (q == 1 ? ShadowQuality.HardOnly : ShadowQuality.All);
        if (sun != null) sun.shadows = q == 0 ? LightShadows.None : (q == 1 ? LightShadows.Hard : LightShadows.Soft);
    }

    // ---------- input + camera ----------
    void HandleInput()
    {
        if (page != Page.Game || paused || showResult) return;
        if (Input.touchCount == 2)
        {
            var a = Input.GetTouch(0); var b = Input.GetTouch(1);
            float d = (a.position - b.position).magnitude;
            float pd = ((a.position - a.deltaPosition) - (b.position - b.deltaPosition)).magnitude;
            zoom = Mathf.Clamp(zoom - (d - pd) * 0.004f, 0.5f, 1.8f);
            dragging = false;
            return;
        }
        if (Input.GetMouseButtonDown(0))
        {
            Vector2 m = Input.mousePosition;
            float x = m.x / Screen.width, y = m.y / Screen.height;
            dragging = x > 0.24f && x < 0.76f && y > 0.15f && y < 0.85f;
            lastMouse = m;
        }
        if (dragging && Input.GetMouseButton(0))
        {
            Vector2 m = Input.mousePosition;
            manualYaw += (m.x - lastMouse.x) * 0.25f;
            manualPitch = Mathf.Clamp(manualPitch - (m.y - lastMouse.y) * 0.15f, -25f, 25f);
            lastMouse = m;
        }
        if (Input.GetMouseButtonUp(0)) dragging = false;
        float sc2 = Input.mouseScrollDelta.y;
        if (Mathf.Abs(sc2) > 0.01f) zoom = Mathf.Clamp(zoom - sc2 * 0.05f, 0.5f, 1.8f);
    }

    void LateUpdate()
    {
        if (cam == null) return;
        float dt = Time.unscaledDeltaTime;
        Vector3 tp = Vector3.zero; float dist = 16f, pitch = 50f, yaw = 0f;
        float ak = Mathf.Max(1f, 1.78f / cam.aspect);
        if (page == Page.Setup)
        {
            tp = new Vector3(-2.2f, 0.9f, -7.5f); dist = 6.5f; pitch = 12f; yaw = Mathf.Sin(Time.time * 0.4f) * 8f;
        }
        else if (page != Page.Game)
        {
            tp = new Vector3(0, 0, -0.5f); dist = 17f * ak; pitch = 38f; yaw = Time.time * 6f;
        }
        else
        {
            CamMode cm = (CamMode)Gi("cam", 0);
            Pl cp = (cur < players.Count) ? players[cur] : null;
            Vector3 cpos = (cp != null && cp.root != null) ? cp.root.position : Vector3.zero;
            switch (cm)
            {
                case CamMode.Iso: tp = new Vector3(0, 0, -0.5f); dist = 16.5f * ak * zoom; pitch = 52f; break;
                case CamMode.Top: tp = Vector3.zero; dist = 15.5f * ak * zoom; pitch = 88f; break;
                case CamMode.Follow: tp = cpos; dist = 9f * zoom; pitch = 42f; break;
                default: tp = new Vector3(0, 0, -0.5f); dist = 15.5f * ak * zoom; pitch = 42f; yaw = Time.time * 8f; break;
            }
            yaw += manualYaw; pitch = Mathf.Clamp(pitch + manualPitch, 8f, 89f);
            switch (camOv)
            {
                case CamOv.Dice: tp = DicePos; dist = 6.5f; pitch = 38f; yaw = 0f; break;
                case CamOv.Snake: if (activeJmp != null) { tp = activeJmp.path[0]; dist = 7f; pitch = 32f; yaw = 0f; } break;
                case CamOv.Ladder: tp = cpos + Vector3.up; dist = 7.5f; pitch = 30f; yaw = 20f; break;
                case CamOv.Victory: tp = cpos + Vector3.up; dist = 5.5f; pitch = 20f; yaw = Time.time * 35f; break;
            }
        }
        float k = 1f - Mathf.Exp(-5f * dt);
        camTP = Vector3.Lerp(camTP, tp, k);
        camDist = Mathf.Lerp(camDist, dist, k);
        camPitch = Mathf.Lerp(camPitch, pitch, k);
        camYaw = Mathf.LerpAngle(camYaw, yaw, k);
        var rot = Quaternion.Euler(camPitch, camYaw, 0f);
        cam.transform.rotation = rot;
        cam.transform.position = camTP - rot * Vector3.forward * camDist;
        float fov = new[] { 35f, 45f, 60f }[Mathf.Clamp(Gi("fov", 1), 0, 2)];
        cam.fieldOfView = Mathf.Lerp(cam.fieldOfView, fov, dt * 4f);
    }

    // ---------- match setup ----------
    void ConfigurePlayers()
    {
        players.Clear();
        var pool = new List<int> { 0, 1, 2, 3, 4, 5 };
        for (int i = pool.Count - 1; i > 0; i--) { int j = Random.Range(0, i + 1); int t = pool[i]; pool[i] = pool[j]; pool[j] = t; }
        int bi = 0;
        for (int i = 0; i < numPlayers; i++)
        {
            var p = new Pl { color = GameData.PlayerColors[i], human = i < numHumans, offset = GameData.Offsets[i] };
            if (p.human)
            {
                p.name = i == 0 ? (string.IsNullOrEmpty(p1Name) ? "Player" : p1Name) : "Player " + (i + 1);
                p.persona = "Human"; p.hat = i == 0 ? p1Hat : (i + 1) % 5;
            }
            else
            {
                int b = pool[bi++ % 6];
                p.name = GameData.BotNames[b]; p.persona = GameData.BotPersona[b]; p.personaIdx = b;
                p.delay = GameData.BotDelay[b]; p.hat = (b + 1) % 5;
            }
            players.Add(p);
        }
    }

    void OpenSetup() { ConfigurePlayers(); BuildWorld(true); page = Page.Setup; }

    void RebuildLobby() { ConfigurePlayers(); BuildWorld(true); }

    void ToHome()
    {
        StopAllCoroutines(); Time.timeScale = 1f; ClearFx();
        matchOver = false; paused = false; showResult = false; camOv = CamOv.None;
        page = Page.Home; ConfigurePlayers(); BuildWorld(true);
    }

    void StartMatch(bool keepPoints)
    {
        StopAllCoroutines(); ClearFx(); Time.timeScale = 1f;
        CheckDay();
        if (!keepPoints) { tourRound = 1; foreach (var p in players) p.points = 0; }
        foreach (var p in players) { p.pos = 0; p.rolls = 0; p.ladders = 0; p.snakes = 0; p.eliminated = false; p.anim = 0; p.bubble = ""; }
        BuildWorld(false);
        cur = 0; roundNo = 0; matchOver = false; paused = false; showResult = false; resultT = 0f; showRoll = false;
        waitRoll = false; rollPressed = false; matchTime = 0f; history.Clear(); resultNote = "";
        camOv = CamOv.None; zoom = 1f; manualYaw = 0f; manualPitch = 0f; winner = null; activeJmp = null;
        page = Page.Game;
        StartCoroutine(MatchLoop());
    }
}
