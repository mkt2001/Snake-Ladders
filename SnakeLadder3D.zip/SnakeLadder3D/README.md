# SNAKE & LADDER 3D - ULTIMATE EDITION (Unity 2022.3 LTS, C#)

Poora game code se hi bana hai (koi external asset/model nahi): 3D board, snakes, ladders, characters,
dice, sounds aur music sab runtime par generate hote hain. UI IMGUI se bani hai (touch ke liye ready).

## APK kaise banayein

### Option A - GitHub Actions (mobile se)
1. Is folder ko GitHub repo me push karo (zip extract karke upload).
2. Repo > Settings > Secrets me `UNITY_LICENSE`, `UNITY_EMAIL`, `UNITY_PASSWORD` daalo
   (game.ci docs: "Activation" - personal licence ke liye activation file chahiye hoti hai).
3. Actions tab > "Build Android APK" > Run workflow. APK artifact `SnakeLadder3D-APK` me milega.

### Option B - PC par Unity
1. Unity Hub se 2022.3.20f1 (ya koi bhi 2022.3 LTS) + Android Build Support install karo.
2. Is folder ko project ki tarah open karo.
3. Menu: SnakeLadder > Prepare Project (scene + Android settings bana deta hai).
4. File > Build Settings > Android > Build.
(Ya batchmode: `-executeMethod BuildScript.BuildAndroid`)

## Controls
- Roll button se dice. Camera: drag = rotate, pinch / +,- = zoom, CAM button = view change.
- Android back button = pause.
