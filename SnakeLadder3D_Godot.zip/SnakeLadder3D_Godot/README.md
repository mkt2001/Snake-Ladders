# Snake & Ladder 3D - Ultimate Edition (Godot 4.2, GDScript)
Poora game code se generate hota hai (koi external asset nahi). Landscape, offline, virtual coins only.
APK GitHub Actions se banti hai (Unity licence ki zaroorat nahi). Repo root me ye zip + .github/workflows/build-apk.yml rakho.
