extends Node3D
# SNAKE & LADDER 3D - ULTIMATE EDITION (Godot 4.2, GDScript). Everything is generated from code.

const TOP = 0.2
const MODES = ["Classic", "Rapid", "Challenge", "Tournament", "Survival", "Lucky Dice", "Hardcore", "Kids", "Night", "Golden"]
const MODE_DESC = [
    "Traditional 100-tile Snake & Ladder.",
    "Fast animations, quick games.",
    "Win within 30 of your own rolls for a bonus.",
    "3 rounds. Points for every rank. Best total wins.",
    "Every 6 rounds the last player is eliminated.",
    "Glowing lucky dice with sparkles. Results stay fair.",
    "Extra snakes, fewer ladders.",
    "Bright, friendly board with fewer snakes.",
    "Dark neon board with glowing snakes and ladders.",
    "Luxury golden board."]
const WORLDS = ["Jungle", "Candy", "Snow", "Space", "Ancient", "Volcano", "Underwater", "Neon Cyber"]
const HATS = ["None", "Party", "Top Hat", "Cap", "Crown"]
const DICE_NAMES = ["Classic", "Golden", "Diamond", "Neon", "Fire", "Ice", "Emerald", "Ruby", "Galaxy", "Candy", "Shadow", "Rainbow"]
const DICE_PRICE = [0, 200, 350, 250, 300, 300, 150, 150, 400, 100, 200, 500]
const DICE_GLOW = [0.0, 0.25, 0.35, 0.8, 0.8, 0.3, 0.2, 0.3, 0.5, 0.1, 0.0, 0.5]
const BOT_NAMES = ["Rocky", "Shelly", "Jokey", "Prof. Brain", "Lucky", "Champ"]
const BOT_PERSONA = ["Aggressive", "Defensive", "Funny", "Intelligent", "Lucky", "Competitive"]
const BOT_DELAY = [0.5, 1.2, 0.9, 1.0, 0.7, 0.6]
# ladder, snake, win, six
const BOT_LINES = [
    ["Out of my way!", "I'll crush that snake!", "Unstoppable!", "SIX! Fear me!"],
    ["Slow and steady.", "Ouch... still safe.", "Careful play pays!", "A safe six."],
    ["Wheee! Elevator!", "Slippery slide, hehe!", "I won! Pizza time!", "Six! Dice love me."],
    ["Calculated.", "Statistically unlucky.", "Elementary.", "Probability 1 in 6."],
    ["Luck is my name!", "Lucky me... oh wait.", "Born lucky!", "Six! Of course."],
    ["Ahead of you all!", "Just a setback.", "Champion again!", "Six! Catch me!"]]
const HUMAN_LINES = ["Yay! Climbing!", "Oh no! A snake!", "I did it!", "Six!"]
const M_LABEL = ["Play 3 matches", "Climb 5 ladders", "Win 1 match", "Weekly: win 5 matches"]
const M_KEY = ["d_play", "d_ladder", "d_win", "w_win"]
const M_TARGET = [3, 5, 1, 5]
const M_REW = [40, 40, 60, 250]
const A_LABEL = ["First Win", "Champion (10 wins)", "Ladder Lover (50)", "Snake Survivor (25 bites)", "Veteran (25 games)", "Reach Level 5"]
const A_KEY = ["wins", "wins", "ladders", "snakes", "games", "level"]
const A_TARGET = [1, 10, 50, 25, 25, 5]
const A_REW = [50, 200, 100, 100, 150, 150]

var DICE_COLORS = [Color(0.96, 0.96, 0.94), Color(1, 0.8, 0.2), Color(0.7, 0.95, 1), Color(0.1, 1, 0.5),
    Color(1, 0.35, 0.05), Color(0.6, 0.85, 1), Color(0.1, 0.7, 0.3), Color(0.85, 0.05, 0.2),
    Color(0.35, 0.15, 0.7), Color(1, 0.5, 0.75), Color(0.12, 0.12, 0.15), Color(1, 0.4, 0.4)]
var PLAYER_COLORS = [Color(0.9, 0.15, 0.15), Color(0.15, 0.4, 0.95), Color(0.15, 0.75, 0.25), Color(1, 0.85, 0.1)]
var OFFSETS = [Vector3(-0.2, 0, -0.2), Vector3(0.2, 0, -0.2), Vector3(-0.2, 0, 0.2), Vector3(0.2, 0, 0.2)]

const GOLD = Color(1, 0.82, 0.2)
const PANEL = Color(0.04, 0.06, 0.16, 0.8)

# ---------- state ----------
var page = "home"
var cam: Camera3D
var env: Environment
var sun: DirectionalLight3D
var world_root: Node3D
var fx_root: Node3D
var ui: CanvasLayer
var players = []
var jumps = {}
var jump_list = []
var th = {}
var sv = {}

var num_players = 2
var num_humans = 1
var mode = 0
var world = 0
var exact_roll = false
var six_again = true
var auto_cam = true
var p1_name = "Player"
var p1_hat = 1
var bot_ids = []

var cur = 0
var last_roll = 1
var round_no = 0
var tour_round = 1
var match_over = false
var rolling = false
var wait_roll = false
var roll_pressed = false
var paused = false
var show_result_flag = false
var show_roll = false
var match_time = 0.0
var history = []
var winner = {}
var reward_coins = 0
var reward_xp = 0
var result_note = ""
var final_order = []
var cam_ov = ""
var active_jmp = {}
var zoom = 1.0
var manual_yaw = 0.0
var manual_pitch = 0.0
var cam_tp = Vector3.ZERO
var cam_dist = 16.0
var cam_pitch = 50.0
var cam_yaw = 0.0

var dice: Node3D
var dice_mat: StandardMaterial3D
var marker: Node3D
var trophy: Node3D
var trophy_t = 0.0
var segs = []
var amb = []
var sparks = []
var hud = {}
var mat_cache = {}
var box_m: BoxMesh
var sph_m: SphereMesh
var cyl_m: CylinderMesh
var cap_m: CapsuleMesh
var sfx_players = []
var music_player: AudioStreamPlayer
var snd = {}

func spd():
    return (1.8 if mode == 1 else 1.0) * float(sv.get("anim", 1.0))

func dice_pos():
    return Vector3(7.4, 0.5, 1.5)

func lobby_pos(i, n):
    return Vector3((i - (n - 1) * 0.5) * 1.8, 0.0, 7.5)

# ---------- save ----------
func gi(k, d = 0):
    return int(sv.get(k, d))

func load_game():
    sv = {"coins": 100, "xp": 0, "games": 0, "wins": 0, "ladders": 0, "snakes": 0, "music_on": 1, "sfx_on": 1,
        "mus_vol": 0.5, "sfx_vol": 1.0, "vib": 1, "hand": 1, "gfx": 2, "fps": 60, "anim": 1.0, "cam": 0, "fov": 1,
        "dice": 0, "dice_own": 1, "pname": "Player", "phat": 1, "streak": 0, "last_daily": "", "m_date": "",
        "d_play": 0, "d_ladder": 0, "d_win": 0, "w_win": 0, "wk_id": -1, "claims": {}, "recent": []}
    if FileAccess.file_exists("user://save.json"):
        var f = FileAccess.open("user://save.json", FileAccess.READ)
        var d = JSON.parse_string(f.get_as_text())
        if typeof(d) == TYPE_DICTIONARY:
            for k in d:
                sv[k] = d[k]
    p1_name = str(sv.get("pname", "Player"))
    p1_hat = gi("phat", 1)

func save_game():
    var f = FileAccess.open("user://save.json", FileAccess.WRITE)
    if f:
        f.store_string(JSON.stringify(sv))

func today():
    return Time.get_date_string_from_system(true)

func check_day():
    if str(sv.m_date) != today():
        sv.m_date = today()
        sv.d_play = 0
        sv.d_ladder = 0
        sv.d_win = 0
        for k in ["d_play", "d_ladder", "d_win"]:
            sv.claims.erase(k)
    var wk = int(Time.get_unix_time_from_system() / 86400.0 / 7.0)
    if gi("wk_id", -1) != wk:
        sv.wk_id = wk
        sv.w_win = 0
        sv.claims.erase("w_win")
    save_game()

func level():
    return 1 + gi("xp") / 150

func add_stat(k, n = 1):
    sv[k] = gi(k) + n

# ---------- lifecycle ----------
func _ready():
    randomize()
    get_tree().quit_on_go_back = false
    load_game()
    check_day()
    init_meshes()
    init_audio()
    cam = Camera3D.new()
    add_child(cam)
    cam.current = true
    cam.fov = 45.0
    fx_root = Node3D.new()
    add_child(fx_root)
    var we = WorldEnvironment.new()
    env = Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.fog_enabled = true
    env.fog_density = 0.008
    we.environment = env
    add_child(we)
    ui = CanvasLayer.new()
    ui.process_mode = Node.PROCESS_MODE_ALWAYS
    add_child(ui)
    apply_quality()

    var cfg = Engine.get_meta("cfg", {})
    if Engine.has_meta("cfg"):
        Engine.remove_meta("cfg")
    if cfg.has("num_players"):
        num_players = cfg.num_players
        num_humans = cfg.num_humans
        mode = cfg.mode
        world = cfg.world
        exact_roll = cfg.exact_roll
        six_again = cfg.six_again
        auto_cam = cfg.auto_cam
        bot_ids = cfg.bot_ids
        tour_round = cfg.tour_round
    var go = str(cfg.get("go", "home"))
    if go == "match":
        configure_players(bot_ids)
        var pts = cfg.get("points", [])
        for i in players.size():
            if i < pts.size():
                players[i].points = pts[i]
        build_world(false)
        begin_match()
    elif go == "setup":
        configure_players(bot_ids)
        build_world(true)
        show_setup()
    else:
        configure_players([])
        build_world(true)
        show_home()

func restart(go):
    var pts = []
    for p in players:
        pts.append(p.points)
    Engine.set_meta("cfg", {"go": go, "num_players": num_players, "num_humans": num_humans, "mode": mode,
        "world": world, "exact_roll": exact_roll, "six_again": six_again, "auto_cam": auto_cam,
        "bot_ids": bot_ids, "tour_round": tour_round, "points": pts})
    Engine.time_scale = 1.0
    get_tree().paused = false
    get_tree().reload_current_scene()

func _notification(what):
    if what == NOTIFICATION_WM_GO_BACK_REQUEST:
        on_back()
    elif what == NOTIFICATION_APPLICATION_PAUSED:
        if page == "game" and not match_over and not paused:
            pause_game(true)

func on_back():
    if page == "game":
        if show_result_flag:
            restart("home")
        else:
            pause_game(not paused)
    elif page == "home":
        get_tree().quit()
    else:
        show_home()

func pause_game(b):
    paused = b
    get_tree().paused = b
    show_game_hud_overlay()

func apply_quality():
    var q = gi("gfx", 2)
    Engine.max_fps = gi("fps", 60)
    get_viewport().msaa_3d = Viewport.MSAA_4X if q >= 3 else (Viewport.MSAA_2X if q == 2 else Viewport.MSAA_DISABLED)
    if sun:
        sun.shadow_enabled = q > 0

func _unhandled_input(event):
    if page != "game" or paused or show_result_flag:
        return
    if event is InputEventMouseMotion and (event.button_mask & MOUSE_BUTTON_MASK_LEFT) != 0:
        manual_yaw += event.relative.x * 0.25
        manual_pitch = clampf(manual_pitch - event.relative.y * 0.15, -25.0, 25.0)
    elif event is InputEventMagnifyGesture:
        zoom = clampf(zoom / maxf(event.factor, 0.1), 0.5, 1.8)
    elif event is InputEventMouseButton and event.pressed:
        if event.button_index == MOUSE_BUTTON_WHEEL_UP:
            zoom = clampf(zoom - 0.07, 0.5, 1.8)
        elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
            zoom = clampf(zoom + 0.07, 0.5, 1.8)

func _process(delta):
    if page == "game" and not match_over and not paused:
        match_time += delta
    animate_pawns()
    animate_world(delta)
    update_fx(delta)
    update_camera(delta)
    update_hud()

func update_camera(delta):
    var d = get_process_delta_time()
    var tp = Vector3.ZERO
    var dist = 16.0
    var pitch = 50.0
    var yaw = 0.0
    var vs = get_viewport().get_visible_rect().size
    var aspect = vs.x / maxf(vs.y, 1.0)
    var ak = maxf(1.0, 1.78 / aspect)
    if page == "setup":
        tp = Vector3(-2.2, 0.9, 7.5)
        dist = 6.5
        pitch = 12.0
        yaw = sin(Time.get_ticks_msec() / 1000.0 * 0.4) * 8.0
    elif page != "game":
        tp = Vector3(0, 0, 0.5)
        dist = 17.0 * ak
        pitch = 38.0
        yaw = Time.get_ticks_msec() / 1000.0 * 6.0
    else:
        var cm = gi("cam", 0)
        var cpos = Vector3.ZERO
        if cur < players.size() and players[cur].root:
            cpos = players[cur].root.global_position
        if cm == 0:
            tp = Vector3(0, 0, 0.5)
            dist = 16.5 * ak * zoom
            pitch = 52.0
        elif cm == 1:
            tp = Vector3.ZERO
            dist = 15.5 * ak * zoom
            pitch = 88.0
        elif cm == 2:
            tp = cpos
            dist = 9.0 * zoom
            pitch = 42.0
        else:
            tp = Vector3(0, 0, 0.5)
            dist = 15.5 * ak * zoom
            pitch = 42.0
            yaw = Time.get_ticks_msec() / 1000.0 * 8.0
        yaw += manual_yaw
        pitch = clampf(pitch + manual_pitch, 8.0, 89.0)
        if cam_ov == "dice":
            tp = dice_pos()
            dist = 6.5
            pitch = 38.0
            yaw = 0.0
        elif cam_ov == "snake" and active_jmp.has("path"):
            tp = active_jmp.path[0]
            dist = 7.0
            pitch = 32.0
            yaw = 0.0
        elif cam_ov == "ladder":
            tp = cpos + Vector3.UP
            dist = 7.5
            pitch = 30.0
            yaw = 20.0
        elif cam_ov == "victory":
            tp = cpos + Vector3.UP
            dist = 5.5
            pitch = 20.0
            yaw = Time.get_ticks_msec() / 1000.0 * 35.0
    var k = 1.0 - exp(-5.0 * d)
    cam_tp = cam_tp.lerp(tp, k)
    cam_dist = lerpf(cam_dist, dist, k)
    cam_pitch = lerpf(cam_pitch, pitch, k)
    cam_yaw = rad_to_deg(lerp_angle(deg_to_rad(cam_yaw), deg_to_rad(yaw), k))
    var b = Basis.from_euler(Vector3(deg_to_rad(-cam_pitch), deg_to_rad(cam_yaw), 0.0))
    cam.global_transform = Transform3D(b, cam_tp + b * Vector3(0, 0, cam_dist))
    var fovs = [35.0, 45.0, 60.0]
    cam.fov = lerpf(cam.fov, fovs[clampi(gi("fov", 1), 0, 2)], k)

# ---------- helpers ----------
func init_meshes():
    box_m = BoxMesh.new()
    sph_m = SphereMesh.new()
    sph_m.radial_segments = 20
    sph_m.rings = 10
    cyl_m = CylinderMesh.new()
    cyl_m.top_radius = 0.5
    cyl_m.bottom_radius = 0.5
    cyl_m.height = 2.0
    cyl_m.radial_segments = 16
    cap_m = CapsuleMesh.new()
    cap_m.radius = 0.5
    cap_m.height = 2.0
    cap_m.radial_segments = 16
    cap_m.rings = 4

func mat(c, rough = 0.6, emis = 0.0):
    var key = "%s_%s_%s" % [c.to_html(), rough, emis]
    if mat_cache.has(key):
        return mat_cache[key]
    var m = StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = rough
    if emis > 0.0:
        m.emission_enabled = true
        m.emission = c
        m.emission_energy_multiplier = emis
    mat_cache[key] = m
    return m

func mat_u(c, rough = 0.6, emis = 0.0):
    var m = StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = rough
    if emis > 0.0:
        m.emission_enabled = true
        m.emission = c
        m.emission_energy_multiplier = emis
    return m

func mnode(mesh, parent, pos, scl, m):
    var n = MeshInstance3D.new()
    n.mesh = mesh
    n.material_override = m
    parent.add_child(n)
    n.position = pos
    n.scale = scl
    return n

func box(parent, pos, scl, m):
    return mnode(box_m, parent, pos, scl, m)

func sph(parent, pos, scl, m):
    return mnode(sph_m, parent, pos, scl, m)

func cyl(parent, pos, scl, m):
    return mnode(cyl_m, parent, pos, scl, m)

func cap(parent, pos, scl, m):
    return mnode(cap_m, parent, pos, scl, m)

func bar(parent, p, q, r, m):
    var d = q - p
    var n = mnode(cyl_m, parent, (p + q) * 0.5, Vector3.ONE, m)
    var yv = d.normalized()
    var ref = Vector3.RIGHT
    if absf(yv.dot(Vector3.RIGHT)) > 0.9:
        ref = Vector3.FORWARD
    var xv = ref.cross(yv).normalized()
    var zv = xv.cross(yv).normalized()
    n.basis = Basis(xv * (r * 2.0), yv * (d.length() * 0.5), zv * (r * 2.0))
    return n

func tile_pos(n):
    if n <= 0:
        return Vector3(-4.5, TOP, 6.0)
    n = mini(n, 100)
    var r = floori((n - 1) / 10.0)
    var c = (n - 1) % 10
    if r % 2 == 1:
        c = 9 - c
    return Vector3(c - 4.5, TOP, 4.5 - r)

func face(node, target):
    var from = node.global_position
    var t = Vector3(target.x, from.y, target.z)
    if from.distance_to(t) > 0.01:
        node.look_at(t, Vector3.UP)

func wait(t):
    await get_tree().create_timer(t, false).timeout

func get_jumps(m):
    var l = [[1, 38], [4, 14], [9, 31], [21, 42], [28, 84], [36, 44], [51, 67], [71, 91], [80, 100],
        [16, 6], [47, 26], [49, 11], [56, 53], [62, 19], [64, 60], [87, 24], [93, 73], [95, 75], [98, 78]]
    if m == 6:
        l = l.filter(func(j): return j[0] != 28 and j[0] != 71)
        l.append_array([[27, 7], [74, 34], [89, 68], [58, 40]])
    if m == 7:
        l = l.filter(func(j): return not (j[0] in [98, 95, 87, 62, 49]))
    return l

# ---------- audio ----------
func env_f(t, dur):
    return clampf(t * 80.0, 0.0, 1.0) * clampf((dur - t) * 20.0, 0.0, 1.0)

func make_wav(dur, fn, loop = false):
    var sr = 22050
    var n = int(dur * sr)
    var bytes = PackedByteArray()
    bytes.resize(n * 2)
    for i in n:
        var v = clampf(fn.call(float(i) / sr), -1.0, 1.0)
        bytes.encode_s16(i * 2, int(v * 30000.0))
    var s = AudioStreamWAV.new()
    s.format = AudioStreamWAV.FORMAT_16_BITS
    s.mix_rate = sr
    s.stereo = false
    s.data = bytes
    if loop:
        s.loop_mode = AudioStreamWAV.LOOP_FORWARD
        s.loop_begin = 0
        s.loop_end = n
    return s

func init_audio():
    for i in 6:
        var a = AudioStreamPlayer.new()
        add_child(a)
        sfx_players.append(a)
    music_player = AudioStreamPlayer.new()
    add_child(music_player)
    snd.click = make_wav(0.07, func(t): return sin(TAU * 900.0 * t) * env_f(t, 0.07) * 0.5)
    snd.rattle = make_wav(0.9, func(t): return (randf() * 2.0 - 1.0) * 0.45 * (0.5 + 0.5 * sin(TAU * 18.0 * t)) * (1.0 - t / 0.9))
    snd.land = make_wav(0.2, func(t): return sin(TAU * 120.0 * t) * exp(-t * 18.0) * 0.9)
    snd.hop = make_wav(0.12, func(t): return sin(TAU * (350.0 * t + 1500.0 * t * t)) * env_f(t, 0.12) * 0.4)
    var arp = [523.3, 659.3, 784.0, 1046.5]
    snd.ladder = make_wav(0.8, func(t): return sin(TAU * arp[mini(3, int(t / 0.2))] * t) * env_f(fmod(t, 0.2), 0.2) * 0.45)
    snd.snake = make_wav(1.0, func(t): return ((randf() * 2.0 - 1.0) * 0.3 + sin(TAU * (500.0 * t - 190.0 * t * t)) * 0.3) * env_f(t, 1.0))
    var ch = [523.3, 659.3, 784.0, 1046.5, 784.0, 1046.5, 1318.5, 1568.0]
    snd.win = make_wav(1.6, func(t): return (sin(TAU * ch[mini(7, int(t / 0.2))] * t) * 0.35 + sin(TAU * ch[mini(7, int(t / 0.2))] * 0.5 * t) * 0.2) * env_f(fmod(t, 0.2), 0.2) * clampf(1.6 - t, 0.0, 1.0))
    snd.lose = make_wav(0.7, func(t): return sin(TAU * (400.0 * t - 300.0 * t * t)) * env_f(t, 0.7) * 0.45)
    snd.music = make_wav(4.0, music_fn, true)
    music_player.stream = snd.music
    apply_audio()

const SEMIS = [0, 2, 4, 7, 9]
const SEQ = [0, 2, 4, 2, 3, 1, 0, 1]

func music_fn(t):
    var ni = mini(7, int(t / 0.5))
    var f = 261.6 * pow(2.0, SEMIS[SEQ[ni]] / 12.0)
    var e = exp(-fmod(t, 0.5) * 4.0)
    return (sin(TAU * f * t) + 0.3 * sin(TAU * f * 2.0 * t)) * 0.18 * e + sin(TAU * 130.8 * t) * 0.08

func apply_audio():
    music_player.volume_db = linear_to_db(maxf(float(sv.get("mus_vol", 0.5)) * 0.6, 0.001))
    if gi("music_on", 1) == 1:
        if not music_player.playing:
            music_player.play()
    else:
        music_player.stop()

func play(s):
    if gi("sfx_on", 1) != 1 or s == null:
        return
    for a in sfx_players:
        if not a.playing:
            a.stream = s
            a.volume_db = linear_to_db(maxf(float(sv.get("sfx_vol", 1.0)), 0.001))
            a.play()
            return

func vibe():
    if gi("vib", 1) == 1:
        Input.vibrate_handheld(300)

# ---------- fx ----------
func burst(pos, ci, n, speed, life, grav, size):
    var cols = [Color(1, 0.8, 0.2), Color(1, 0.2, 0.2), Color(0.2, 1, 0.3), Color(0.3, 0.5, 1), Color(1, 1, 0.3), Color(1, 0.4, 0.8), Color(1, 1, 1), Color(0.3, 1, 1)]
    for i in n:
        if sparks.size() > 350:
            return
        var c = cols[randi() % cols.size()] if ci < 0 else cols[ci % cols.size()]
        var m = mnode(box_m, fx_root, pos, Vector3.ONE * size * randf_range(0.6, 1.2), mat(c, 0.5, 1.0))
        m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        var v = Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1)).normalized() * speed * randf_range(0.4, 1.0)
        sparks.append({"n": m, "v": v, "life": life * randf_range(0.7, 1.0), "grav": grav,
            "spin": Vector3(randf_range(-6, 6), randf_range(-6, 6), randf_range(-6, 6))})

func update_fx(dt):
    var i = sparks.size() - 1
    while i >= 0:
        var s = sparks[i]
        s.life -= dt
        if s.life <= 0.0:
            s.n.queue_free()
            sparks.remove_at(i)
        else:
            s.v.y += s.grav * dt
            s.n.position += s.v * dt
            s.n.rotation += s.spin * dt
            if s.life < 0.4:
                s.n.scale *= 0.92
        i -= 1

# ---------- world ----------
func c3(r, g, b):
    return Color(r, g, b)

func get_theme(w, m):
    var t = {"glow": 0.0, "floor_glow": 0.0, "fx": 0}
    var ww = 7 if m == 8 else w
    match ww:
        0:
            t.bg = c3(.45, .75, .6); t.a = c3(.55, .8, .35); t.b = c3(.33, .58, .25); t.frame = c3(.4, .25, .12); t.floor = c3(.12, .38, .14); t.amb = c3(.5, .55, .45); t.fx = 5
        1:
            t.bg = c3(1, .75, .88); t.a = c3(1, .6, .75); t.b = c3(.7, .9, 1); t.frame = c3(1, .4, .6); t.floor = c3(1, .85, .9); t.amb = c3(.6, .5, .55); t.fx = 6
        2:
            t.bg = c3(.75, .88, 1); t.a = c3(.95, .97, 1); t.b = c3(.65, .82, .95); t.frame = c3(.5, .7, .85); t.floor = c3(.9, .95, 1); t.amb = c3(.55, .6, .7); t.fx = 1
        3:
            t.bg = c3(.02, .02, .1); t.a = c3(.25, .25, .5); t.b = c3(.15, .15, .35); t.frame = c3(.5, .3, .8); t.floor = c3(.02, .02, .08); t.amb = c3(.3, .3, .45); t.fx = 4; t.glow = 0.2
        4:
            t.bg = c3(.9, .75, .5); t.a = c3(.95, .85, .55); t.b = c3(.75, .55, .3); t.frame = c3(.85, .65, .15); t.floor = c3(.6, .4, .25); t.amb = c3(.55, .5, .4); t.fx = 0
        5:
            t.bg = c3(.25, .05, .02); t.a = c3(.35, .2, .18); t.b = c3(.2, .1, .1); t.frame = c3(.8, .25, .05); t.floor = c3(.9, .25, 0); t.floor_glow = 0.5; t.amb = c3(.45, .3, .25); t.fx = 3; t.glow = 0.1
        6:
            t.bg = c3(0, .3, .5); t.a = c3(.4, .85, .9); t.b = c3(.2, .6, .8); t.frame = c3(.9, .6, .4); t.floor = c3(.9, .85, .6); t.amb = c3(.35, .5, .6); t.fx = 2
        _:
            t.bg = c3(.03, 0, .12); t.a = c3(.12, .06, .3); t.b = c3(.06, .03, .18); t.frame = c3(0, .9, 1); t.floor = c3(.02, 0, .07); t.amb = c3(.25, .2, .4); t.fx = 4; t.glow = 0.5
    if m == 9:
        t.a = c3(1, .85, .35); t.b = c3(.85, .62, .12); t.frame = c3(.55, .35, .05); t.glow = 0.15
    return t

func build_world(lobby):
    if world_root:
        world_root.queue_free()
    world_root = Node3D.new()
    add_child(world_root)
    segs = []
    amb = []
    trophy = null
    trophy_t = 0.0
    th = get_theme(world, mode)
    env.background_color = th.bg
    env.ambient_light_color = th.amb
    env.fog_light_color = th.bg
    sun = DirectionalLight3D.new()
    world_root.add_child(sun)
    sun.rotation_degrees = Vector3(-55, -35, 0)
    sun.light_energy = 1.15
    sun.light_color = Color.WHITE.lerp(th.a, 0.25)
    sun.shadow_enabled = gi("gfx", 2) > 0
    box(world_root, Vector3(0, -0.05, 0), Vector3(70, 0.1, 70), mat(th.floor, 0.5, th.floor_glow))
    box(world_root, Vector3.ZERO, Vector3(11, 0.3, 11), mat(th.frame, 0.4, th.glow))
    var mA = mat(th.a, 0.35, th.glow)
    var mB = mat(th.b, 0.35, th.glow)
    jumps = {}
    jump_list = []
    for pr in get_jumps(mode):
        var j = {"from": pr[0], "to": pr[1], "snake": pr[1] < pr[0], "mats": [], "glow_cur": 0.0, "glow_target": 0.0, "base": Color.WHITE}
        jumps[pr[0]] = j
        jump_list.append(j)
    for n in range(1, 101):
        var p = tile_pos(n)
        var r = floori((n - 1) / 10.0)
        var c = (n - 1) % 10
        var alt = ((r + c) % 2 == 0)
        var m = mA if alt else mB
        if n == 100:
            m = mat(c3(1, .8, .2), 0.3, 0.3)
        elif n == 1:
            m = mat(c3(.3, .6, 1), 0.35, th.glow)
        elif jumps.has(n):
            var base = th.a if alt else th.b
            m = mat(base.lerp(c3(1, .25, .25) if jumps[n].snake else c3(.3, 1, .4), 0.45), 0.35, th.glow)
        box(world_root, Vector3(p.x, TOP - 0.05, p.z), Vector3(0.96, 0.1, 0.96), m)
        var l = Label3D.new()
        l.text = str(n)
        l.font_size = 40
        l.pixel_size = 0.0055
        l.modulate = Color(0, 0, 0, 0.8)
        l.outline_size = 0
        world_root.add_child(l)
        l.position = Vector3(p.x - 0.27, TOP + 0.012, p.z + 0.3)
        l.rotation_degrees = Vector3(-90, 0, 0)
    var si = 0
    for j in jump_list:
        if j.snake:
            build_snake(j, si)
            si += 1
        else:
            build_ladder(j)
    cyl(world_root, Vector3(dice_pos().x, 0.02, dice_pos().z), Vector3(2.4, 0.03, 2.4), mat(th.frame, 0.4, th.glow))
    build_dice()
    decor()
    ambient()
    marker = box(world_root, Vector3(0, -50, 0), Vector3.ONE * 0.3, mat(c3(1, .85, .2), 0.3, 0.8))
    marker.rotation_degrees = Vector3(45, 45, 0)
    for i in players.size():
        build_pawn(players[i], i, lobby)

# ladders and snakes
func lad_pt(j, k):
    var p = tile_pos(j.from).lerp(tile_pos(j.to), k)
    p.y = TOP + 0.08 + k * 0.9
    return p

func build_ladder(j):
    var root = Node3D.new()
    world_root.add_child(root)
    var a = lad_pt(j, 0.0)
    var b = lad_pt(j, 1.0)
    var dir = b - a
    var flat = Vector3(dir.x, 0, dir.z).normalized()
    var sdir = Vector3.UP.cross(flat)
    var side = sdir * 0.2
    j.base = c3(.85, .6, .25)
    var mr = mat_u(j.base, 0.4, 0.2)
    var mrung = mat_u(c3(.95, .8, .4), 0.4, 0.2)
    j.mats = [mr, mrung]
    bar(root, a + side, b + side, 0.05, mr)
    bar(root, a - side, b - side, 0.05, mr)
    var rungs = maxi(2, int(dir.length() / 0.55))
    for i in range(1, rungs + 1):
        var k = i / float(rungs + 1)
        var n = mnode(box_m, root, a.lerp(b, k), Vector3.ONE, mrung)
        n.basis = Basis(sdir * 0.44, Vector3.UP * 0.05, flat * 0.06)
    for s in [-1.0, 1.0]:
        bar(root, Vector3(b.x + side.x * s, 0.15, b.z + side.z * s), b + side * s, 0.05, mr)

func build_snake(j, idx):
    var root = Node3D.new()
    world_root.add_child(root)
    var hp = tile_pos(j.from)
    var tp = tile_pos(j.to)
    var dir = tp - hp
    var flat = Vector3(dir.x, 0, dir.z)
    var side = Vector3.UP.cross(flat.normalized())
    var n = clampi(int(dir.length() * 4.0), 16, 44)
    var path = []
    var amp = minf(0.9, flat.length() * 0.1 + 0.3)
    var waves = 1.0 + flat.length() / 5.0
    var ph = idx * 1.7
    for i in n:
        var t = i / float(n - 1)
        var p = hp.lerp(tp, t)
        p += side * sin(t * PI * 2.0 * waves + ph) * amp * sin(t * PI)
        p.y = lerpf(TOP + 0.55, TOP + 0.1, t)
        path.append(p)
    j.path = path
    var pal = [c3(.1, .6, .2), c3(.7, .2, .6), c3(.9, .5, .1), c3(.2, .4, .8), c3(.6, .6, .1), c3(.8, .15, .15)]
    var bc = pal[idx % pal.size()]
    var glow = 0.6 if th.glow > 0.0 else 0.05
    var m1 = mat(bc, 0.35, glow)
    var m2 = mat(bc.lerp(Color.WHITE, 0.45), 0.35, glow)
    j.base = bc
    for i in range(1, n):
        var t = i / float(n - 1)
        var r = lerpf(0.2, 0.09, t)
        var g = sph(root, path[i], Vector3.ONE * r * 2.2, m1 if (i / 2) % 2 == 0 else m2)
        segs.append({"n": g, "bp": path[i], "side": side, "ph": i * 0.6 + idx})
    var fwd = path[0] - path[mini(2, n - 1)]
    fwd.y = 0
    if fwd.length() < 0.01:
        fwd = Vector3(0, 0, 1)
    var head = Node3D.new()
    root.add_child(head)
    head.position = path[0]
    head.look_at(path[0] + fwd.normalized(), Vector3.UP)
    j.head = head
    sph(head, Vector3.ZERO, Vector3(0.55, 0.38, 0.62), m1)
    var m_eye = mat(c3(1, .9, .1), 0.3, 1.0)
    var m_k = mat(c3(.02, .02, .02), 0.5)
    for s in [-1.0, 1.0]:
        var e = sph(head, Vector3(0.17 * s, 0.13, -0.2), Vector3.ONE * 0.14, m_eye)
        sph(e, Vector3(0, 0, -0.4), Vector3(0.3, 0.8, 0.3), m_k)
        box(head, Vector3(0.1 * s, -0.07, -0.3), Vector3(0.04, 0.1, 0.04), mat(Color.WHITE, 0.4))
    var jaw = Node3D.new()
    head.add_child(jaw)
    jaw.position = Vector3(0, -0.1, -0.05)
    box(jaw, Vector3(0, 0, -0.22), Vector3(0.34, 0.07, 0.46), m2)
    box(head, Vector3(0, -0.05, -0.55), Vector3(0.04, 0.02, 0.3), mat(c3(.9, .1, .15), 0.5))
    j.jaw = jaw

# pawn
func build_pawn(p, idx, lobby):
    var root = Node3D.new()
    world_root.add_child(root)
    var inner = Node3D.new()
    root.add_child(inner)
    var m_body = mat(p.color, 0.5)
    var m_skin = mat(c3(1, .83, .66), 0.6)
    var m_w = mat(Color.WHITE, 0.3)
    var m_k = mat(c3(.05, .05, .08), 0.5)
    cap(inner, Vector3(0, 0.42, 0), Vector3(0.5, 0.32, 0.5), m_body)
    var head = sph(inner, Vector3(0, 0.95, 0), Vector3.ONE * 0.46, m_skin)
    for sx in [-1.0, 1.0]:
        var eye = sph(head, Vector3(0.22 * sx, 0.1, -0.4), Vector3.ONE * 0.28, m_w)
        sph(eye, Vector3(0, 0, -0.38), Vector3.ONE * 0.55, m_k)
    box(head, Vector3(0, -0.2, -0.45), Vector3(0.3, 0.07, 0.1), m_k)
    var arms = []
    for s in 2:
        var sx = -1.0 if s == 0 else 1.0
        var piv = Node3D.new()
        inner.add_child(piv)
        piv.position = Vector3(0.3 * sx, 0.62, 0)
        cap(piv, Vector3(0, -0.18, 0), Vector3(0.14, 0.2, 0.14), m_skin)
        arms.append(piv)
        sph(inner, Vector3(0.12 * sx, 0.06, -0.05), Vector3(0.2, 0.12, 0.3), m_k)
    var m_gold = mat(c3(1, .8, .2), 0.3, 0.2)
    if p.hat == 1:
        var mh = mat(p.color.lerp(Color.WHITE, 0.3), 0.5)
        cyl(inner, Vector3(0, 1.22, 0), Vector3(0.34, 0.06, 0.34), mh)
        cyl(inner, Vector3(0, 1.34, 0), Vector3(0.24, 0.06, 0.24), mh)
        cyl(inner, Vector3(0, 1.46, 0), Vector3(0.12, 0.06, 0.12), mh)
    elif p.hat == 2:
        var mt = mat(c3(.08, .08, .1), 0.4)
        cyl(inner, Vector3(0, 1.17, 0), Vector3(0.6, 0.02, 0.6), mt)
        cyl(inner, Vector3(0, 1.35, 0), Vector3(0.38, 0.17, 0.38), mt)
    elif p.hat == 3:
        var mc = mat(p.color, 0.5)
        sph(inner, Vector3(0, 1.12, 0), Vector3(0.52, 0.36, 0.52), mc)
        box(inner, Vector3(0, 1.1, -0.26), Vector3(0.34, 0.03, 0.3), mc)
    elif p.hat == 4:
        cyl(inner, Vector3(0, 1.2, 0), Vector3(0.4, 0.08, 0.4), m_gold)
        for i in 5:
            var a = i * TAU / 5.0
            box(inner, Vector3(cos(a) * 0.17, 1.33, sin(a) * 0.17), Vector3(0.07, 0.14, 0.07), m_gold)
    root.scale = Vector3.ONE * 0.85 * (1.15 if mode == 7 else 1.0)
    p.root = root
    p.inner = inner
    p.head = head
    p.arml = arms[0]
    p.armr = arms[1]
    p.anim = 0
    if lobby:
        root.position = lobby_pos(idx, players.size())
        root.look_at(root.position + Vector3(0, 0, 1), Vector3.UP)
    else:
        root.position = tile_pos(p.pos) + p.offset
        root.look_at(root.position + Vector3(0, 0, -1), Vector3.UP)

# dice
func pip_pattern(v):
    match v:
        1: return [Vector2(0, 0)]
        2: return [Vector2(-1, -1), Vector2(1, 1)]
        3: return [Vector2(-1, -1), Vector2(0, 0), Vector2(1, 1)]
        4: return [Vector2(-1, -1), Vector2(1, 1), Vector2(-1, 1), Vector2(1, -1)]
        5: return [Vector2(-1, -1), Vector2(1, 1), Vector2(-1, 1), Vector2(1, -1), Vector2(0, 0)]
    return [Vector2(-1, -1), Vector2(-1, 0), Vector2(-1, 1), Vector2(1, -1), Vector2(1, 0), Vector2(1, 1)]

func face_up(v):
    match v:
        1: return Basis.IDENTITY
        6: return Basis.from_euler(Vector3(PI, 0, 0))
        3: return Basis.from_euler(Vector3(0, 0, PI / 2.0))
        4: return Basis.from_euler(Vector3(0, 0, -PI / 2.0))
        2: return Basis.from_euler(Vector3(-PI / 2.0, 0, 0))
    return Basis.from_euler(Vector3(PI / 2.0, 0, 0))

func build_dice():
    dice = Node3D.new()
    world_root.add_child(dice)
    var sk = clampi(gi("dice", 0), 0, DICE_NAMES.size() - 1)
    var c = DICE_COLORS[sk]
    dice_mat = StandardMaterial3D.new()
    dice_mat.albedo_color = c
    dice_mat.roughness = 0.25
    if DICE_GLOW[sk] > 0.0:
        dice_mat.emission_enabled = true
        dice_mat.emission = c
        dice_mat.emission_energy_multiplier = DICE_GLOW[sk]
    mnode(box_m, dice, Vector3.ZERO, Vector3.ONE * 0.9, dice_mat)
    var lum = c.r * 0.3 + c.g * 0.59 + c.b * 0.11
    var pm = mat(c3(.1, .1, .15) if lum > 0.5 else Color.WHITE, 0.4)
    var normals = [Vector3.UP, Vector3.DOWN, Vector3.RIGHT, Vector3.LEFT, Vector3.BACK, Vector3.FORWARD]
    var vals = [1, 6, 3, 4, 2, 5]
    for f in 6:
        var n = normals[f]
        var t1 = Vector3.RIGHT
        var t2 = Vector3.BACK
        if absf(n.y) > 0.5:
            t1 = Vector3.RIGHT
            t2 = Vector3.BACK
        elif absf(n.x) > 0.5:
            t1 = Vector3.UP
            t2 = Vector3.BACK
        else:
            t1 = Vector3.RIGHT
            t2 = Vector3.UP
        for ab in pip_pattern(vals[f]):
            sph(dice, n * 0.45 + t1 * ab.x * 0.22 + t2 * ab.y * 0.22, Vector3.ONE * 0.15, pm)
    dice.position = dice_pos()
    dice.basis = face_up(last_roll)

func refresh_dice_skin():
    if dice:
        dice.queue_free()
    build_dice()

# decor + ambient
func decor():
    var rnd = RandomNumberGenerator.new()
    rnd.seed = world * 7 + 3
    var n = 16
    for i in n:
        var ang = i * TAU / n + rnd.randf() * 0.2
        var rad = 9.5 + rnd.randf() * 4.0
        var p = Vector3(cos(ang) * rad, 0, sin(ang) * rad * 0.9)
        if p.z > 7.0 and absf(p.x) < 6.0:
            continue
        if absf(p.x - dice_pos().x) < 2.5 and absf(p.z - dice_pos().z) < 2.5:
            continue
        prop(7 if mode == 8 else world, p, rnd)

func prop(w, p, r):
    var s = 0.8 + r.randf() * 0.8
    var up = Vector3.UP
    var rc = [c3(1, .4, .6), c3(.4, .8, 1), c3(1, .85, .3), c3(.6, .5, 1), c3(.4, 1, .6)]
    var col = rc[r.randi() % rc.size()]
    match w:
        0:
            cyl(world_root, p + up * s, Vector3(0.4 * s, s, 0.4 * s), mat(c3(.4, .25, .1)))
            sph(world_root, p + up * 2.6 * s, Vector3.ONE * 2.0 * s, mat(c3(.15, .55 + r.randf() * .2, .2)))
        1:
            cyl(world_root, p + up * 1.2, Vector3(0.12, 1.2, 0.12), mat(Color.WHITE))
            sph(world_root, p + up * 2.6, Vector3.ONE * 1.3 * s, mat(col, 0.3, 0.2))
        2:
            var wh = mat(c3(.97, .97, 1), 0.8)
            sph(world_root, p + up * 0.8 * s, Vector3.ONE * 1.6 * s, wh)
            sph(world_root, p + up * 2.0 * s, Vector3.ONE * 1.1 * s, wh)
            sph(world_root, p + up * 2.9 * s, Vector3.ONE * 0.7 * s, wh)
            box(world_root, p + up * 2.9 * s + Vector3(0, 0, 0.35 * s), Vector3(0.1, 0.1, 0.3) * s, mat(c3(1, .5, .1)))
        3:
            sph(world_root, p + up * (3.0 + r.randf() * 4.0), Vector3.ONE * 3.0 * s, mat(col, 0.6, 0.25))
        4:
            cyl(world_root, p + up * 1.3 * s, Vector3(0.9, 1.3 * s, 0.9), mat(c3(.95, .88, .7)))
            box(world_root, p + up * 2.7 * s, Vector3(1.5, 0.3, 1.5), mat(c3(1, .8, .2), 0.3, 0.2))
        5:
            sph(world_root, p + up * 0.6, Vector3(2.0 * s, 1.5 * s, 2.0 * s), mat(c3(.15, .1, .1)))
            sph(world_root, p + up * 1.3 * s, Vector3.ONE * 0.6, mat(c3(1, .4, .05), 0.5, 1.0))
        6:
            for k in 3:
                var h = 0.8 + r.randf() * 1.4
                var q = p + Vector3(k * 0.4 - 0.4, 0, 0)
                cyl(world_root, q + up * h * 0.5, Vector3(0.25, h * 0.5, 0.25), mat(col, 0.4, 0.2))
                sph(world_root, q + up * h, Vector3.ONE * 0.4, mat(col, 0.4, 0.2))
        _:
            cyl(world_root, p + up * 1.5, Vector3(0.5, 1.5, 0.5), mat(col, 0.3, 1.0))

func ambient():
    if th.fx == 0:
        return
    var n = 60 if gi("gfx", 2) >= 2 else 25
    var m = mat(Color.WHITE, 0.5, 0.4)
    match th.fx:
        1: m = mat(Color.WHITE, 0.5, 0.5)
        2: m = mat(c3(.7, .95, 1), 0.3, 0.3)
        3: m = mat(c3(1, .45, .1), 0.5, 1.5)
        4: m = mat(Color.WHITE, 0.5, 1.2)
        5: m = mat(c3(.9, 1, .3), 0.5, 1.5)
    for i in n:
        var mm = m
        if th.fx == 6:
            mm = mat(Color.from_hsv(randf(), 0.5, 1.0), 0.5, 0.4)
        var sz = 0.3 if th.fx == 4 else 0.12
        var g = sph(world_root, Vector3.ZERO, Vector3.ONE * sz, mm)
        g.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        var pos = Vector3(randf_range(-13, 13), randf_range(0, 12), randf_range(-13, 13))
        if th.fx == 4:
            pos = Vector3(randf_range(-1, 1), randf_range(-0.2, 1), randf_range(-1, 1)).normalized() * 28.0
            pos.y = absf(pos.y) + 2.0
        g.position = pos
        amb.append({"n": g, "spd": randf_range(0.4, 1.2), "ph": randf_range(0, 6)})

# animation
func animate_pawns():
    var t = Time.get_ticks_msec() / 1000.0
    for i in players.size():
        var p = players[i]
        if p.root == null:
            continue
        var ph = i * 1.3
        var ip = Vector3.ZERO
        var rot_y = 0.0
        var al = 0.0
        var ar = 0.0
        var tilt = 0.0
        match p.anim:
            0:
                ip.y = sin(t * 2.0 + ph) * 0.02
                al = sin(t * 2.0 + ph) * 8.0
                ar = -al
                tilt = sin(t * 1.3 + ph) * 6.0
            1:
                ip.y = absf(sin(t * 10.0)) * 0.05
                al = sin(t * 12.0) * 40.0
                ar = -al
            2:
                ip.y = absf(sin(t * 7.0 + ph)) * 0.35
                al = 150.0 + sin(t * 14.0) * 25.0
                ar = 150.0 - sin(t * 14.0) * 25.0
                rot_y = t * 400.0 if p.pidx % 2 == 0 else sin(t * 6.0) * 30.0
                if page == "game":
                    p.root.look_at(Vector3(cam.global_position.x, p.root.global_position.y, cam.global_position.z), Vector3.UP)
            3:
                tilt = -25.0
                al = 10.0
                ar = 10.0
                ip.y = -0.02
            4:
                ip.y = absf(sin(t * 8.0)) * 0.04
                al = 120.0 + sin(t * 9.0) * 50.0
                ar = 120.0 - sin(t * 9.0) * 50.0
        p.inner.position = ip
        p.inner.rotation = Vector3(0, deg_to_rad(rot_y), 0)
        p.arml.rotation = Vector3(deg_to_rad(al), 0, 0)
        p.armr.rotation = Vector3(deg_to_rad(ar), 0, 0)
        p.head.rotation = Vector3(deg_to_rad(tilt), 0, 0)
    if marker:
        var on = page == "game" and not match_over and cur < players.size() and players[cur].root != null and not players[cur].eliminated
        if on:
            marker.position = players[cur].root.global_position + Vector3.UP * (1.9 + sin(t * 4.0) * 0.1)
            marker.rotate_y(2.0 * get_process_delta_time())
        else:
            marker.position = Vector3(0, -50, 0)

func animate_world(dt):
    var tm = Time.get_ticks_msec() / 1000.0
    for s in segs:
        s.n.position = s.bp + s.side * sin(tm * 4.0 + s.ph) * 0.06 + Vector3.UP * sin(tm * 3.0 + s.ph) * 0.02
    for a in amb:
        var p = a.n.position
        match th.fx:
            1, 6:
                p.y -= a.spd * dt
                p.x += sin(tm + a.ph) * 0.3 * dt
                if p.y < 0.0:
                    p.y = 12.0
            2, 3:
                p.y += a.spd * dt
                p.x += sin(tm * 1.3 + a.ph) * 0.4 * dt
                if p.y > 12.0:
                    p.y = 0.0
            5:
                p.y += sin(tm + a.ph) * 0.4 * dt
                p.x += cos(tm * 0.7 + a.ph) * 0.5 * dt
            4:
                a.n.scale = Vector3.ONE * (0.25 + 0.12 * sin(tm * 2.0 + a.ph))
        a.n.position = p
    for j in jump_list:
        if j.snake:
            continue
        j.glow_cur = move_toward(j.glow_cur, j.glow_target, dt * 3.0)
        for m in j.mats:
            m.emission_energy_multiplier = 0.2 + j.glow_cur
    if dice and dice_mat:
        if gi("dice", 0) == 11:
            dice_mat.albedo_color = Color.from_hsv(fmod(tm * 0.2, 1.0), 0.6, 1.0)
        if mode == 5 and randf() < 0.15:
            burst(dice.position, -1, 1, 1.0, 0.8, -0.3, 0.06)
        if not rolling:
            dice.position = dice_pos() + Vector3.UP * sin(tm * 2.0) * 0.03
    if trophy:
        trophy_t = minf(1.0, trophy_t + get_process_delta_time() * 1.5)
        trophy.scale = Vector3.ONE * trophy_t * 1.3
        trophy.rotate_y(1.6 * get_process_delta_time())

func build_trophy(w):
    var t = Node3D.new()
    world_root.add_child(t)
    t.position = w.root.global_position + Vector3.UP * 2.4
    t.scale = Vector3.ZERO
    var gold = mat(c3(1, .8, .15), 0.2, 0.3)
    cyl(t, Vector3(0, -0.3, 0), Vector3(0.5, 0.04, 0.5), gold)
    cyl(t, Vector3(0, -0.15, 0), Vector3(0.1, 0.12, 0.1), gold)
    sph(t, Vector3(0, 0.1, 0), Vector3(0.55, 0.45, 0.55), gold)
    for s in [-1.0, 1.0]:
        sph(t, Vector3(0.3 * s, 0.1, 0), Vector3(0.18, 0.18, 0.06), gold)
    trophy = t
    trophy_t = 0.0

# ---------- players / match ----------
func configure_players(ids):
    players = []
    var pool = [0, 1, 2, 3, 4, 5]
    pool.shuffle()
    var need = num_players - num_humans
    if ids.size() != need:
        bot_ids = pool.slice(0, need)
    else:
        bot_ids = ids
    var bi = 0
    for i in num_players:
        var p = {"name": "", "persona": "Human", "pidx": 0, "color": PLAYER_COLORS[i], "human": i < num_humans,
            "pos": 0, "hat": 0, "rolls": 0, "ladders": 0, "snakes": 0, "points": 0, "eliminated": false,
            "offset": OFFSETS[i], "root": null, "inner": null, "head": null, "arml": null, "armr": null,
            "anim": 0, "delay": 0.8, "bub": null, "bub_until": 0.0}
        if p.human:
            p.name = (p1_name if p1_name != "" else "Player") if i == 0 else "Player " + str(i + 1)
            p.hat = p1_hat if i == 0 else (i + 1) % 5
        else:
            var b = bot_ids[bi]
            bi += 1
            p.name = BOT_NAMES[b]
            p.persona = BOT_PERSONA[b]
            p.pidx = b
            p.delay = BOT_DELAY[b]
            p.hat = (b + 1) % 5
        players.append(p)

func line(p, i):
    return HUMAN_LINES[i] if p.human else BOT_LINES[p.pidx][i]

func say(p, t):
    if p.bub == null:
        var l = Label3D.new()
        l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
        l.no_depth_test = true
        l.font_size = 48
        l.pixel_size = 0.008
        l.outline_size = 14
        l.outline_modulate = Color(0, 0, 0, 1)
        l.modulate = Color(1, 1, 0.6)
        world_root.add_child(l)
        p.bub = l
    p.bub.text = t
    p.bub_until = Time.get_ticks_msec() / 1000.0 + 2.2

func log_event(s):
    history.push_front(s)
    if history.size() > 8:
        history.pop_back()

func begin_match():
    check_day()
    for p in players:
        p.pos = 0
        p.rolls = 0
        p.ladders = 0
        p.snakes = 0
        p.eliminated = false
        p.anim = 0
    cur = 0
    round_no = 0
    match_over = false
    paused = false
    show_result_flag = false
    show_roll = false
    wait_roll = false
    roll_pressed = false
    match_time = 0.0
    history = []
    result_note = ""
    cam_ov = ""
    zoom = 1.0
    winner = {}
    active_jmp = {}
    page = "game"
    show_game_hud()
    match_loop()

func match_loop():
    await wait(0.8)
    while not match_over:
        var p = players[cur]
        if p.eliminated:
            cur = (cur + 1) % players.size()
            continue
        cam_ov = ""
        if p.human:
            wait_roll = true
            roll_pressed = false
            while not roll_pressed:
                await get_tree().process_frame
            wait_roll = false
        else:
            await wait(p.delay / spd())
        await roll_dice()
        var r = last_roll
        p.rolls += 1
        log_event(p.name + " rolled " + str(r))
        if r == 6:
            say(p, line(p, 3))
        await move_flow(p, r)
        cam_ov = ""
        active_jmp = {}
        if p.pos >= 100:
            match_over = true
            end_match(p)
            return
        var again = six_again and r == 6
        if not again:
            var prev = cur
            cur = (cur + 1) % players.size()
            while players[cur].eliminated:
                cur = (cur + 1) % players.size()
            if cur <= prev:
                round_no += 1
                if mode == 4 and round_no % 6 == 0:
                    await eliminate_last()
        await wait(0.25 / spd())

func eliminate_last():
    var act = 0
    for p in players:
        if not p.eliminated:
            act += 1
    if act <= 2:
        return
    var low = null
    for p in players:
        if not p.eliminated and (low == null or p.pos < low.pos):
            low = p
    low.eliminated = true
    low.anim = 3
    say(low, "Eliminated!")
    log_event(low.name + " eliminated")
    play(snd.lose)
    await wait(1.1)
    low.root.visible = false
    if players[cur] == low:
        cur = (cur + 1) % players.size()
        while players[cur].eliminated:
            cur = (cur + 1) % players.size()

func _dice_step(k, base, axis, rot0, dur):
    dice.position = base + Vector3.UP * (absf(sin(k * PI * 3.0)) * (1.0 - k) * 1.6)
    dice.basis = Basis(axis, k * dur * 12.0 * (1.0 - k * 0.35)) * rot0

func _dice_settle(k, q0, q1, base):
    dice.basis = Basis(q0.slerp(q1, k))
    dice.position = dice.position.lerp(base, 0.3)

func roll_dice():
    last_roll = randi_range(1, 6)
    show_roll = false
    rolling = true
    cam_ov = "dice" if auto_cam else ""
    play(snd.rattle)
    var dur = 1.05 / spd()
    var base = dice_pos()
    var axis = Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1)).normalized()
    var rot0 = dice.basis
    var tw = create_tween()
    tw.tween_method(_dice_step.bind(base, axis, rot0, dur), 0.0, 1.0, dur)
    await tw.finished
    var q0 = dice.basis.get_rotation_quaternion()
    var q1 = (Basis(Vector3.UP, randf() * TAU) * face_up(last_roll)).get_rotation_quaternion()
    var tw2 = create_tween()
    tw2.tween_method(_dice_settle.bind(q0, q1, base), 0.0, 1.0, 0.25)
    await tw2.finished
    dice.position = base
    dice.basis = Basis(q1)
    rolling = false
    show_roll = true
    play(snd.land)
    await wait(0.35 / spd())
    cam_ov = ""

func move_flow(p, r):
    var target = p.pos + r
    if target > 100:
        if exact_roll:
            say(p, "Need exact roll!")
            return
        target = 100
    p.anim = 1
    while p.pos < target:
        await hop(p, tile_pos(p.pos + 1) + p.offset, 0.26 / spd(), 0.45)
        p.pos += 1
    p.anim = 0
    if p.pos >= 100:
        return
    if jumps.has(p.pos):
        var j = jumps[p.pos]
        active_jmp = j
        if j.snake:
            await snake_flow(p, j)
        else:
            await ladder_flow(p, j)

func _hop_step(k, p, from, to, arc):
    p.root.global_position = from.lerp(to, k) + Vector3.UP * arc * 4.0 * k * (1.0 - k)

func hop(p, to, dur, arc):
    var from = p.root.global_position
    face(p.root, to)
    play(snd.hop)
    var tw = create_tween()
    tw.tween_method(_hop_step.bind(p, from, to, arc), 0.0, 1.0, dur)
    await tw.finished
    p.root.global_position = to

func _climb_step(k, p, j):
    var pt = lad_pt(j, k) + Vector3.UP * 0.05 + p.offset * 0.3
    p.root.global_position = pt
    var nxt = lad_pt(j, minf(1.0, k + 0.05))
    face(p.root, nxt)
    if randf() < 0.08:
        burst(pt, 0, 3, 2.0, 0.7, -1.5, 0.09)

func ladder_flow(p, j):
    cam_ov = "ladder" if auto_cam else ""
    say(p, line(p, 0))
    await wait(0.3 / spd())
    p.anim = 4
    play(snd.ladder)
    j.glow_target = 1.5
    var tw = create_tween()
    tw.tween_method(_climb_step.bind(p, j), 0.0, 1.0, 1.7 / spd())
    await tw.finished
    p.anim = 0
    await hop(p, tile_pos(j.to) + p.offset, 0.4 / spd(), 0.6)
    p.pos = j.to
    p.ladders += 1
    add_stat("ladders")
    add_stat("d_ladder")
    log_event(p.name + " climbed " + str(j.from) + " > " + str(j.to))
    p.anim = 2
    burst(p.root.global_position + Vector3.UP, 0, 25, 3.0, 1.0, -3.0, 0.1)
    await wait(0.7 / spd())
    p.anim = 0
    j.glow_target = 0.0

func _jaw_step(k, j):
    j.jaw.rotation = Vector3(deg_to_rad(-40.0 * k), 0, 0)
    j.head.scale = Vector3.ONE * (1.0 + 0.3 * k)

func _slide_step(k, p, j):
    var L = j.path.size() - 1
    var f = k * L
    var i0 = mini(int(f), j.path.size() - 2)
    p.root.global_position = j.path[i0].lerp(j.path[i0 + 1], f - i0) + Vector3.UP * 0.15
    p.root.rotate_y(0.2)

func snake_flow(p, j):
    cam_ov = "snake" if auto_cam else ""
    await wait(0.3 / spd())
    play(snd.snake)
    vibe()
    var tw = create_tween()
    tw.tween_method(_jaw_step.bind(j), 0.0, 1.0, 0.5 / spd())
    await tw.finished
    p.anim = 3
    say(p, line(p, 1))
    await hop(p, j.path[0] + Vector3.UP * 0.1, 0.25 / spd(), 0.2)
    var tw2 = create_tween()
    tw2.tween_method(_slide_step.bind(p, j), 0.0, 1.0, 1.6 / spd())
    await tw2.finished
    j.jaw.rotation = Vector3.ZERO
    j.head.scale = Vector3.ONE
    await hop(p, tile_pos(j.to) + p.offset, 0.3 / spd(), 0.3)
    p.pos = j.to
    p.snakes += 1
    add_stat("snakes")
    log_event(p.name + " bitten " + str(j.from) + " > " + str(j.to))
    await wait(0.7 / spd())
    p.anim = 0

func end_match(w):
    winner = w
    match_over = true
    wait_roll = false
    w.pos = 100
    w.anim = 2
    cam_ov = "victory"
    for o in players:
        if o != w and not o.eliminated:
            o.anim = 3
    play(snd.win)
    say(w, line(w, 2))
    build_trophy(w)
    Engine.time_scale = 0.35
    celebrate(w)

    final_order = players.duplicate()
    final_order.sort_custom(func(a, b): return a.pos > b.pos)
    final_order.erase(w)
    final_order.insert(0, w)
    var pts = [4, 2, 1, 0]
    for i in final_order.size():
        final_order[i].points += pts[mini(i, 3)]

    var me = players[0] if players[0].human else null
    if w.human:
        reward_coins = 50 + 10 * (players.size() - 1)
        reward_xp = 60
    elif me != null:
        reward_coins = 10
        reward_xp = 20
    else:
        reward_coins = 5
        reward_xp = 10
    if mode == 1:
        reward_coins = int(reward_coins * 0.8)
    if mode == 6:
        reward_coins = int(reward_coins * 1.5)
    result_note = ""
    if mode == 2 and me != null:
        if w == me and me.rolls <= 30:
            reward_coins += 100
            result_note = "Challenge complete! +100 bonus"
        else:
            result_note = "Challenge failed (win within 30 rolls)"
    if mode == 3:
        if tour_round < 3:
            result_note = "Round " + str(tour_round) + " of 3 finished"
        else:
            var champ = players[0]
            for p in players:
                if p.points > champ.points:
                    champ = p
            result_note = "TOURNAMENT CHAMPION: " + champ.name + " (" + str(champ.points) + " pts)"
            reward_coins += 100
    add_stat("coins", reward_coins)
    add_stat("xp", reward_xp)
    add_stat("games")
    add_stat("d_play")
    if w.human:
        add_stat("wins")
        add_stat("d_win")
        add_stat("w_win")
    var rec = sv.recent
    rec.push_front(w.name)
    while rec.size() > 8:
        rec.pop_back()
    save_game()

    await get_tree().create_timer(1.4, false, false, true).timeout
    Engine.time_scale = 1.0
    await get_tree().create_timer(2.5, false).timeout
    show_result_flag = true
    show_result()

func celebrate(w):
    for i in 10:
        burst(w.root.global_position + Vector3.UP * 4.0, -1, 30, 3.5, 4.5, -3.2, 0.13)
        burst(Vector3(randf_range(-4, 4), randf_range(3.5, 6.5), randf_range(-3, 4)), -1, 30, 4.0, 1.4, -2.5, 0.1)
        await wait(0.6)

func next_round():
    tour_round += 1
    restart("match")

func rematch():
    tour_round = 1
    for p in players:
        p.points = 0
    restart("match")

# ---------- UI helpers ----------
func vsize():
    return get_viewport().get_visible_rect().size

func new_page():
    for c in ui.get_children():
        c.queue_free()
    hud = {}
    var root = Control.new()
    root.set_anchors_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    ui.add_child(root)
    return root

func lbl(parent, text, pos, size, fs, color = Color.WHITE, align = HORIZONTAL_ALIGNMENT_CENTER):
    var l = Label.new()
    l.text = text
    l.position = pos
    l.size = size
    l.add_theme_font_size_override("font_size", fs)
    l.add_theme_color_override("font_color", color)
    l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
    l.add_theme_constant_override("outline_size", 5)
    l.horizontal_alignment = align
    l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    l.mouse_filter = Control.MOUSE_FILTER_IGNORE
    parent.add_child(l)
    return l

func panel(parent, pos, size, color = PANEL):
    var p = Panel.new()
    p.position = pos
    p.size = size
    var sb = StyleBoxFlat.new()
    sb.bg_color = color
    sb.set_corner_radius_all(16)
    p.add_theme_stylebox_override("panel", sb)
    p.mouse_filter = Control.MOUSE_FILTER_IGNORE
    parent.add_child(p)
    return p

func btn(parent, text, pos, size, color, cb, fs = 26):
    var b = Button.new()
    b.text = text
    b.position = pos
    b.size = size
    b.focus_mode = Control.FOCUS_NONE
    b.add_theme_font_size_override("font_size", fs)
    b.add_theme_color_override("font_color", Color.WHITE)
    b.add_theme_color_override("font_hover_color", Color.WHITE)
    b.add_theme_color_override("font_pressed_color", Color.WHITE)
    b.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.7))
    b.add_theme_constant_override("outline_size", 4)
    for st in ["normal", "hover", "pressed"]:
        var sb = StyleBoxFlat.new()
        var c = color
        if st == "hover":
            c = color.lightened(0.12)
        elif st == "pressed":
            c = color.darkened(0.2)
        sb.bg_color = c
        sb.set_corner_radius_all(16)
        sb.border_width_bottom = 5
        sb.border_color = color.darkened(0.45)
        b.add_theme_stylebox_override(st, sb)
    b.pressed.connect(_btn_pressed.bind(cb))
    parent.add_child(b)
    return b

func _btn_pressed(cb):
    play(snd.click)
    cb.call()

func fmt_time(t):
    var s = int(t)
    return "%02d:%02d" % [s / 60, s % 60]

func top_bar(root, title):
    var w = vsize().x
    panel(root, Vector2(0, 0), Vector2(w, 70), Color(0, 0, 0, 0.6))
    btn(root, "< BACK", Vector2(12, 10), Vector2(150, 50), Color(0.3, 0.33, 0.45), show_home, 22)
    lbl(root, title, Vector2(0, 0), Vector2(w, 70), 38, GOLD)
    lbl(root, "Coins %d   Lv %d" % [gi("coins"), level()], Vector2(w - 400, 0), Vector2(390, 70), 24, GOLD, HORIZONTAL_ALIGNMENT_RIGHT)

# ---------- HOME ----------
func show_home():
    page = "home"
    get_tree().paused = false
    var root = new_page()
    var w = vsize().x
    lbl(root, "Coins %d     Level %d     XP %d" % [gi("coins"), level(), gi("xp")], Vector2(20, 8), Vector2(700, 50), 26, GOLD, HORIZONTAL_ALIGNMENT_LEFT)
    lbl(root, "SNAKE &", Vector2(20, 130), Vector2(w * 0.5, 120), 96, Color(1, 0.95, 0.7))
    lbl(root, "LADDER 3D", Vector2(20, 240), Vector2(w * 0.5, 120), 96, GOLD)
    lbl(root, "ULTIMATE EDITION", Vector2(20, 360), Vector2(w * 0.5, 60), 38, Color.WHITE)
    var names = ["PLAY NOW", "PLAY WITH BOTS", "LOCAL MULTIPLAYER", "TOURNAMENT", "PREMIUM MODES", "DICE COLLECTION", "DAILY REWARDS", "STATS", "SETTINGS", "EXIT"]
    var cols = [Color(0.15, 0.7, 0.3), Color(0.15, 0.45, 0.95), Color(0.5, 0.25, 0.85), Color(0.85, 0.2, 0.2), Color(0.85, 0.65, 0.1), Color(0.15, 0.45, 0.95), Color(0.15, 0.7, 0.3), Color(0.5, 0.25, 0.85), Color(0.3, 0.33, 0.45), Color(0.85, 0.2, 0.2)]
    var x0 = w - 700
    for i in names.size():
        var pos = Vector2(x0 + (i % 2) * 345, 90 + floori(i / 2.0) * 110)
        btn(root, names[i], pos, Vector2(330, 94), cols[i], _home_action.bind(i), 28)

func _home_action(i):
    match i:
        0:
            num_players = 2; num_humans = 1; mode = 0; open_setup()
        1:
            num_players = 4; num_humans = 1; mode = 0; open_setup()
        2:
            num_players = 2; num_humans = 2; mode = 0; open_setup()
        3:
            num_players = 4; num_humans = 1; mode = 3; open_setup()
        4:
            num_players = 4; num_humans = 1; mode = 9; open_setup()
        5:
            show_shop()
        6:
            show_rewards()
        7:
            show_stats()
        8:
            show_settings()
        9:
            get_tree().quit()

func open_setup():
    configure_players([])
    build_world(true)
    show_setup()

func rebuild_lobby():
    configure_players([])
    build_world(true)
    show_setup()

# ---------- SETUP / LOBBY ----------
func show_setup():
    page = "setup"
    var root = new_page()
    var w = vsize().x
    var gold = Color(0.85, 0.65, 0.1)
    var grey = Color(0.3, 0.33, 0.45)
    var blue = Color(0.15, 0.45, 0.95)
    var purple = Color(0.5, 0.25, 0.85)
    panel(root, Vector2(10, 10), Vector2(660, 700))
    lbl(root, "3D LOBBY", Vector2(24, 14), Vector2(300, 44), 30, GOLD, HORIZONTAL_ALIGNMENT_LEFT)
    lbl(root, "PLAYERS", Vector2(24, 64), Vector2(150, 56), 24, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
    for i in 3:
        btn(root, str(i + 2), Vector2(180 + i * 100, 64), Vector2(90, 56), gold if num_players == i + 2 else grey, _set_players.bind(i + 2), 26)
    lbl(root, "HUMANS", Vector2(24, 128), Vector2(150, 56), 24, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
    for i in 5:
        if i <= num_players:
            btn(root, str(i), Vector2(180 + i * 84, 128), Vector2(76, 56), gold if num_humans == i else grey, _set_humans.bind(i), 26)
    lbl(root, "MODE", Vector2(24, 192), Vector2(300, 36), 24, GOLD, HORIZONTAL_ALIGNMENT_LEFT)
    for i in 10:
        btn(root, MODES[i], Vector2(24 + (i % 5) * 126, 232 + floori(i / 5.0) * 62), Vector2(120, 56), gold if mode == i else blue, _set_mode.bind(i), 18)
    lbl(root, "WORLD", Vector2(24, 362), Vector2(300, 36), 24, GOLD, HORIZONTAL_ALIGNMENT_LEFT)
    for i in 8:
        btn(root, WORLDS[i], Vector2(24 + (i % 4) * 158, 402 + floori(i / 4.0) * 62), Vector2(150, 56), gold if world == i else purple, _set_world.bind(i), 20)
    btn(root, "Exact roll: " + ("ON" if exact_roll else "OFF"), Vector2(24, 536), Vector2(200, 52), Color(0.15, 0.7, 0.3) if exact_roll else grey, _toggle.bind("exact"), 20)
    btn(root, "6 = again: " + ("ON" if six_again else "OFF"), Vector2(232, 536), Vector2(200, 52), Color(0.15, 0.7, 0.3) if six_again else grey, _toggle.bind("six"), 20)
    btn(root, "Auto cam: " + ("ON" if auto_cam else "OFF"), Vector2(440, 536), Vector2(200, 52), Color(0.15, 0.7, 0.3) if auto_cam else grey, _toggle.bind("cam"), 20)
    lbl(root, "NAME", Vector2(24, 598), Vector2(100, 52), 22, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
    var le = LineEdit.new()
    le.text = p1_name
    le.max_length = 12
    le.position = Vector2(120, 598)
    le.size = Vector2(250, 52)
    le.add_theme_font_size_override("font_size", 26)
    le.text_changed.connect(_name_changed)
    root.add_child(le)
    btn(root, "Hat: " + HATS[p1_hat], Vector2(384, 598), Vector2(256, 52), purple, _next_hat, 22)
    btn(root, "< BACK", Vector2(24, 656), Vector2(160, 48), grey, show_home, 22)

    panel(root, Vector2(w - 560, 10), Vector2(550, 150))
    lbl(root, MODES[mode] + "  -  " + WORLDS[world], Vector2(w - 550, 14), Vector2(530, 48), 30, GOLD, HORIZONTAL_ALIGNMENT_LEFT)
    var d = lbl(root, MODE_DESC[mode], Vector2(w - 550, 62), Vector2(530, 90), 22, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
    d.autowrap_mode = TextServer.AUTOWRAP_WORD
    btn(root, "START MATCH", Vector2(w - 440, 600), Vector2(420, 100), Color(0.15, 0.7, 0.3), start_match, 40)

func _set_players(n):
    num_players = n
    if num_humans > n:
        num_humans = n
    rebuild_lobby()

func _set_humans(n):
    num_humans = n
    rebuild_lobby()

func _set_mode(i):
    mode = i
    rebuild_lobby()

func _set_world(i):
    world = i
    rebuild_lobby()

func _toggle(k):
    if k == "exact":
        exact_roll = not exact_roll
    elif k == "six":
        six_again = not six_again
    else:
        auto_cam = not auto_cam
    show_setup()

func _name_changed(t):
    p1_name = t
    sv.pname = t
    if players.size() > 0 and players[0].human:
        players[0].name = t if t != "" else "Player"

func _next_hat():
    p1_hat = (p1_hat + 1) % HATS.size()
    sv.phat = p1_hat
    save_game()
    rebuild_lobby()

func start_match():
    save_game()
    tour_round = 1
    for p in players:
        p.points = 0
    restart("match")

# ---------- GAME HUD ----------
func show_game_hud():
    var root = new_page()
    var w = vsize().x
    hud.root = root
    hud.cards = []
    for i in players.size():
        var y = 80 + i * 118
        var pc = panel(root, Vector2(8, y), Vector2(330, 110), Color(0, 0, 0, 0.6))
        var strip = ColorRect.new()
        strip.color = players[i].color
        strip.position = Vector2(8, 8)
        strip.size = Vector2(14, 94)
        strip.mouse_filter = Control.MOUSE_FILTER_IGNORE
        pc.add_child(strip)
        var n = lbl(pc, "", Vector2(30, 4), Vector2(295, 36), 24, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
        var inf = lbl(pc, "", Vector2(30, 40), Vector2(295, 32), 22, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
        var rk = lbl(pc, "", Vector2(30, 72), Vector2(295, 30), 20, GOLD, HORIZONTAL_ALIGNMENT_LEFT)
        hud.cards.append({"panel": pc, "name": n, "info": inf, "rank": rk})
    panel(root, Vector2(w / 2 - 250, 6), Vector2(500, 76), Color(0, 0, 0, 0.55))
    hud.top = lbl(root, "", Vector2(w / 2 - 250, 6), Vector2(500, 38), 24, GOLD)
    hud.turn = lbl(root, "", Vector2(w / 2 - 250, 42), Vector2(500, 38), 28, Color.WHITE)
    hud.pause = btn(root, "PAUSE", Vector2(w - 170, 8), Vector2(160, 60), Color(0.3, 0.33, 0.45), _on_pause_pressed, 24)
    panel(root, Vector2(w - 330, 80), Vector2(322, 330))
    lbl(root, "TURN HISTORY", Vector2(w - 330, 84), Vector2(322, 36), 22, GOLD)
    hud.hist = lbl(root, "", Vector2(w - 322, 122), Vector2(306, 280), 20, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
    hud.hist.vertical_alignment = VERTICAL_ALIGNMENT_TOP
    hud.cambtn = btn(root, "CAM", Vector2(w - 330, 420), Vector2(170, 56), Color(0.15, 0.45, 0.95), _cycle_cam, 22)
    btn(root, "+", Vector2(w - 152, 420), Vector2(70, 56), Color(0.15, 0.45, 0.95), _zoom_in, 32)
    btn(root, "-", Vector2(w - 76, 420), Vector2(68, 56), Color(0.15, 0.45, 0.95), _zoom_out, 32)
    hud.mus = btn(root, "", Vector2(w - 330, 486), Vector2(158, 50), Color(0.15, 0.7, 0.3), _toggle_music, 20)
    hud.sfxb = btn(root, "", Vector2(w - 166, 486), Vector2(158, 50), Color(0.15, 0.7, 0.3), _toggle_sfx, 20)
    lbl(root, "Drag: rotate   Pinch: zoom", Vector2(w - 330, 540), Vector2(322, 34), 18, Color(1, 1, 1, 0.65))
    var rx = 12.0 if gi("hand", 1) == 0 else w - 330.0
    hud.rollx = rx
    hud.roll = btn(root, "ROLL DICE", Vector2(rx, 600), Vector2(318, 104), Color(0.15, 0.7, 0.3), _on_roll, 40)
    hud.status = lbl(root, "", Vector2(rx, 600), Vector2(318, 104), 26, Color.WHITE)
    hud.rollnum = lbl(root, "", Vector2(w / 2 + 100, 250), Vector2(300, 140), 110, GOLD)

func _on_pause_pressed():
    if not match_over:
        pause_game(true)

func _on_roll():
    roll_pressed = true

func _cycle_cam():
    sv.cam = (gi("cam", 0) + 1) % 4
    save_game()

func _zoom_in():
    zoom = maxf(0.5, zoom - 0.15)

func _zoom_out():
    zoom = minf(1.8, zoom + 0.15)

func _toggle_music():
    sv.music_on = 1 - gi("music_on", 1)
    apply_audio()
    save_game()

func _toggle_sfx():
    sv.sfx_on = 1 - gi("sfx_on", 1)
    save_game()

func update_hud():
    var now = Time.get_ticks_msec() / 1000.0
    for p in players:
        if p.bub != null and is_instance_valid(p.bub):
            p.bub.visible = now < p.bub_until and p.root != null
            if p.root:
                p.bub.global_position = p.root.global_position + Vector3.UP * 2.3
    if page != "game" or not hud.has("cards"):
        return
    var ranked = players.duplicate()
    ranked.sort_custom(func(a, b): return a.pos > b.pos)
    for i in players.size():
        var p = players[i]
        var c = hud.cards[i]
        c.name.text = p.name + ("" if p.human else " [" + p.persona + "]")
        c.info.text = "OUT" if p.eliminated else "Tile %d  (%d to go)" % [p.pos, 100 - p.pos]
        c.rank.text = "Rank %d%s" % [ranked.find(p) + 1, ("   Pts %d" % p.points) if mode == 3 else ""]
        c.panel.modulate = Color(1, 0.9, 0.4) if (i == cur and not match_over) else Color.WHITE
    hud.top.text = MODES[mode] + ("  Round %d/3" % tour_round if mode == 3 else "") + "   " + fmt_time(match_time)
    hud.turn.text = "" if match_over else players[cur].name + "'s turn"
    var lines = ""
    for h in history:
        lines += h + "\n"
    hud.hist.text = lines
    hud.cambtn.text = "CAM: " + ["Iso", "Top", "Follow", "Cine"][gi("cam", 0)]
    hud.mus.text = "Music " + ("ON" if gi("music_on", 1) == 1 else "OFF")
    hud.sfxb.text = "SFX " + ("ON" if gi("sfx_on", 1) == 1 else "OFF")
    var my_turn = (not match_over) and players[cur].human and wait_roll and not paused
    hud.roll.visible = my_turn
    hud.status.visible = not my_turn
    hud.status.text = "" if match_over else (players[cur].name + " is playing" if not players[cur].human else "Rolling...")
    hud.rollnum.text = ("+" + str(last_roll)) if (show_roll and not match_over) else ""
    hud.pause.disabled = match_over

func show_game_hud_overlay():
    if hud.has("pause_ov") and is_instance_valid(hud.pause_ov):
        hud.pause_ov.queue_free()
    if not paused:
        return
    var w = vsize().x
    var ov = Control.new()
    ov.set_anchors_preset(Control.PRESET_FULL_RECT)
    ui.add_child(ov)
    hud.pause_ov = ov
    var dim = ColorRect.new()
    dim.color = Color(0, 0, 0, 0.65)
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    ov.add_child(dim)
    lbl(ov, "PAUSED", Vector2(0, 90), Vector2(w, 100), 80, GOLD)
    var cx = w / 2 - 200
    btn(ov, "RESUME", Vector2(cx, 220), Vector2(400, 84), Color(0.15, 0.7, 0.3), _resume, 38)
    btn(ov, "RESTART", Vector2(cx, 320), Vector2(400, 84), Color(0.15, 0.45, 0.95), _restart_match, 38)
    btn(ov, "HOME", Vector2(cx, 420), Vector2(400, 84), Color(0.85, 0.2, 0.2), _go_home, 38)

func _resume():
    pause_game(false)

func _restart_match():
    tour_round = 1
    for p in players:
        p.points = 0
    restart("match")

func _go_home():
    restart("home")

func show_result():
    var w = vsize().x
    var ov = Control.new()
    ov.set_anchors_preset(Control.PRESET_FULL_RECT)
    ui.add_child(ov)
    var dim = ColorRect.new()
    dim.color = Color(0, 0, 0, 0.55)
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    ov.add_child(dim)
    var x = w / 2 - 480
    panel(ov, Vector2(x, 20), Vector2(960, 680), Color(0.04, 0.06, 0.16, 0.94))
    lbl(ov, "WINNER: " + winner.name, Vector2(x, 28), Vector2(960, 70), 56, GOLD)
    lbl(ov, result_note, Vector2(x, 98), Vector2(960, 40), 26, Color.WHITE)
    var cols = ["#", "PLAYER", "TILE", "ROLLS", "LADDERS", "SNAKES", "PTS"]
    var cx = [20, 90, 420, 520, 640, 780, 880]
    for i in cols.size():
        lbl(ov, cols[i], Vector2(x + cx[i], 142), Vector2(110, 34), 20, GOLD, HORIZONTAL_ALIGNMENT_LEFT)
    for i in final_order.size():
        var p = final_order[i]
        var y = 180 + i * 62
        var row = panel(ov, Vector2(x + 12, y), Vector2(936, 56), Color(p.color.r * 0.5, p.color.g * 0.5, p.color.b * 0.5, 0.9))
        var vals = [str(i + 1), p.name, str(p.pos), str(p.rolls), str(p.ladders), str(p.snakes), str(p.points)]
        for k in vals.size():
            lbl(ov, vals[k], Vector2(x + cx[k], y), Vector2(300 if k == 1 else 110, 56), 26, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
    lbl(ov, "Time " + fmt_time(match_time), Vector2(x, 440), Vector2(960, 36), 24, Color.WHITE)
    lbl(ov, "+%d coins     +%d XP" % [reward_coins, reward_xp], Vector2(x, 484), Vector2(960, 60), 44, GOLD)
    if mode == 3 and tour_round < 3:
        btn(ov, "NEXT ROUND", Vector2(x + 60, 570), Vector2(390, 96), Color(0.15, 0.7, 0.3), next_round, 38)
    else:
        btn(ov, "REMATCH", Vector2(x + 60, 570), Vector2(390, 96), Color(0.15, 0.7, 0.3), rematch, 38)
    btn(ov, "HOME", Vector2(x + 510, 570), Vector2(390, 96), Color(0.85, 0.2, 0.2), _go_home, 38)

# ---------- SHOP ----------
func show_shop():
    page = "shop"
    var root = new_page()
    var w = vsize().x
    panel(root, Vector2(0, 0), Vector2(w, 720), Color(0, 0, 0, 0.55))
    top_bar(root, "DICE COLLECTION")
    var own = gi("dice_own", 1)
    var sel = gi("dice", 0)
    var cw = (w - 50) / 4.0
    for i in DICE_NAMES.size():
        var x = 10 + (i % 4) * (cw + 10)
        var y = 82 + floori(i / 4.0) * 208
        var owned = (own & (1 << i)) != 0
        panel(root, Vector2(x, y), Vector2(cw, 198))
        var sw = ColorRect.new()
        sw.color = DICE_COLORS[i]
        sw.position = Vector2(x + cw / 2 - 40, y + 14)
        sw.size = Vector2(80, 80)
        root.add_child(sw)
        lbl(root, DICE_NAMES[i], Vector2(x, y + 98), Vector2(cw, 40), 26)
        var t = "SELECTED" if i == sel else ("USE" if owned else str(DICE_PRICE[i]) + " coins")
        var col = Color(0.85, 0.65, 0.1) if i == sel else (Color(0.15, 0.45, 0.95) if owned else (Color(0.15, 0.7, 0.3) if gi("coins") >= DICE_PRICE[i] else Color(0.3, 0.33, 0.45)))
        btn(root, t, Vector2(x + 12, y + 140), Vector2(cw - 24, 48), col, _shop_action.bind(i), 22)

func _shop_action(i):
    var own = gi("dice_own", 1)
    if (own & (1 << i)) != 0:
        sv.dice = i
    elif gi("coins") >= DICE_PRICE[i]:
        sv.coins = gi("coins") - DICE_PRICE[i]
        sv.dice_own = own | (1 << i)
        sv.dice = i
    save_game()
    refresh_dice_skin()
    show_shop()

# ---------- REWARDS ----------
func stat_val(k):
    return level() if k == "level" else gi(k)

func show_rewards():
    page = "rewards"
    var root = new_page()
    var w = vsize().x
    panel(root, Vector2(0, 0), Vector2(w, 720), Color(0, 0, 0, 0.55))
    top_bar(root, "REWARDS")
    var can = str(sv.last_daily) != today()
    panel(root, Vector2(10, 80), Vector2(w - 20, 90))
    lbl(root, "Daily reward - streak %d day(s)" % gi("streak"), Vector2(30, 80), Vector2(700, 90), 32, GOLD, HORIZONTAL_ALIGNMENT_LEFT)
    var b = btn(root, "CLAIM TODAY" if can else "CLAIMED", Vector2(w - 330, 96), Vector2(310, 58), Color(0.15, 0.7, 0.3) if can else Color(0.3, 0.33, 0.45), _claim_daily, 26)
    b.disabled = not can
    lbl(root, "DAILY MISSIONS / WEEKLY CHALLENGE", Vector2(10, 178), Vector2(700, 40), 24, GOLD, HORIZONTAL_ALIGNMENT_LEFT)
    for i in 4:
        var y = 222 + i * 72
        var v = mini(gi(M_KEY[i]), M_TARGET[i])
        var done = v >= M_TARGET[i]
        var claimed = sv.claims.has(M_KEY[i])
        panel(root, Vector2(10, y), Vector2(w - 20, 64))
        lbl(root, "%s  (%d/%d)" % [M_LABEL[i], v, M_TARGET[i]], Vector2(30, y), Vector2(700, 64), 26, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
        var bb = btn(root, "CLAIMED" if claimed else "CLAIM +%d" % M_REW[i], Vector2(w - 330, y + 6), Vector2(310, 52), Color(0.15, 0.7, 0.3) if (done and not claimed) else Color(0.3, 0.33, 0.45), _claim_mission.bind(i), 22)
        bb.disabled = claimed or not done
    lbl(root, "ACHIEVEMENTS", Vector2(10, 516), Vector2(500, 36), 24, GOLD, HORIZONTAL_ALIGNMENT_LEFT)
    for i in 6:
        var hw = (w - 30) / 2.0
        var x = 10 + (i % 2) * (hw + 10)
        var y = 556 + floori(i / 2.0) * 54
        var v = mini(stat_val(A_KEY[i]), A_TARGET[i])
        var done = v >= A_TARGET[i]
        var claimed = sv.claims.has("a" + str(i))
        panel(root, Vector2(x, y), Vector2(hw, 50))
        lbl(root, "%s %d/%d" % [A_LABEL[i], v, A_TARGET[i]], Vector2(x + 10, y), Vector2(hw - 190, 50), 18, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
        var ab = btn(root, "CLAIMED" if claimed else "+%d" % A_REW[i], Vector2(x + hw - 175, y + 4), Vector2(165, 42), Color(0.15, 0.7, 0.3) if (done and not claimed) else Color(0.3, 0.33, 0.45), _claim_ach.bind(i), 18)
        ab.disabled = claimed or not done

func _claim_daily():
    var yday = Time.get_date_string_from_unix_time(int(Time.get_unix_time_from_system()) - 86400)
    var streak = gi("streak")
    streak = streak + 1 if str(sv.last_daily) == yday else 1
    sv.streak = streak
    sv.last_daily = today()
    add_stat("coins", 25 + mini(streak, 7) * 15)
    add_stat("xp", 20)
    save_game()
    show_rewards()

func _claim_mission(i):
    sv.claims[M_KEY[i]] = 1
    add_stat("coins", M_REW[i])
    save_game()
    show_rewards()

func _claim_ach(i):
    sv.claims["a" + str(i)] = 1
    add_stat("coins", A_REW[i])
    save_game()
    show_rewards()

# ---------- STATS ----------
func show_stats():
    page = "stats"
    var root = new_page()
    var w = vsize().x
    panel(root, Vector2(0, 0), Vector2(w, 720), Color(0, 0, 0, 0.55))
    top_bar(root, "STATS / LEADERBOARD")
    var g = gi("games")
    var wn = gi("wins")
    panel(root, Vector2(10, 84), Vector2(640, 520))
    var lines = ["Level %d   (XP %d)" % [level(), gi("xp")], "Coins %d" % gi("coins"), "Games played %d" % g, "Wins %d" % wn,
        "Win rate %d%%" % (100 * wn / g if g > 0 else 0), "Ladders climbed %d" % gi("ladders"), "Snake bites %d" % gi("snakes")]
    for i in lines.size():
        lbl(root, lines[i], Vector2(34, 96 + i * 66), Vector2(600, 60), 32, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
    panel(root, Vector2(670, 84), Vector2(w - 680, 520))
    lbl(root, "RECENT WINNERS", Vector2(690, 90), Vector2(500, 50), 30, GOLD, HORIZONTAL_ALIGNMENT_LEFT)
    var rec = sv.recent
    for i in rec.size():
        lbl(root, "%d. %s" % [i + 1, str(rec[i])], Vector2(700, 146 + i * 52), Vector2(500, 48), 28, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)

# ---------- SETTINGS ----------
func choice_row(root, label, pos, width, opts, sel, key, vals):
    lbl(root, label, pos, Vector2(190, 60), 24, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
    var bw = (width - 195) / opts.size()
    for i in opts.size():
        btn(root, str(opts[i]), Vector2(pos.x + 195 + i * bw, pos.y), Vector2(bw - 6, 60), Color(0.85, 0.65, 0.1) if i == sel else Color(0.3, 0.33, 0.45), _set_pref.bind(key, vals[i]), 20)

func _set_pref(key, val):
    sv[key] = val
    save_game()
    apply_quality()
    apply_audio()
    show_settings()

func show_settings():
    page = "settings"
    var root = new_page()
    var w = vsize().x
    panel(root, Vector2(0, 0), Vector2(w, 720), Color(0, 0, 0, 0.55))
    top_bar(root, "SETTINGS")
    var cw = w / 2.0 - 25
    var x1 = 15.0
    var x2 = w / 2.0 + 10
    var off_on = ["Off", "On"]
    var vol = ["0%", "25%", "50%", "75%", "100%"]
    var vv = [0.0, 0.25, 0.5, 0.75, 1.0]
    choice_row(root, "Music", Vector2(x1, 90), cw, off_on, gi("music_on", 1), "music_on", [0, 1])
    choice_row(root, "Sound FX", Vector2(x1, 164), cw, off_on, gi("sfx_on", 1), "sfx_on", [0, 1])
    choice_row(root, "Music vol", Vector2(x1, 238), cw, vol, roundi(float(sv.mus_vol) * 4.0), "mus_vol", vv)
    choice_row(root, "SFX vol", Vector2(x1, 312), cw, vol, roundi(float(sv.sfx_vol) * 4.0), "sfx_vol", vv)
    choice_row(root, "Vibration", Vector2(x1, 386), cw, off_on, gi("vib", 1), "vib", [0, 1])
    choice_row(root, "Hand", Vector2(x1, 460), cw, ["Left", "Right"], gi("hand", 1), "hand", [0, 1])
    choice_row(root, "Graphics", Vector2(x2, 90), cw, ["Low", "Med", "High", "Ultra"], gi("gfx", 2), "gfx", [0, 1, 2, 3])
    choice_row(root, "FPS", Vector2(x2, 164), cw, ["30", "60", "90"], [30, 60, 90].find(gi("fps", 60)), "fps", [30, 60, 90])
    choice_row(root, "Anim speed", Vector2(x2, 238), cw, ["0.75x", "1x", "1.5x", "2x"], [0.75, 1.0, 1.5, 2.0].find(float(sv.anim)), "anim", [0.75, 1.0, 1.5, 2.0])
    choice_row(root, "Camera", Vector2(x2, 312), cw, ["Iso", "Top", "Follow", "Cine"], gi("cam", 0), "cam", [0, 1, 2, 3])
    choice_row(root, "Perspective", Vector2(x2, 386), cw, ["Narrow", "Normal", "Wide"], gi("fov", 1), "fov", [0, 1, 2])
    lbl(root, "In a match: drag = rotate camera, pinch or +/- = zoom, CAM = change view.", Vector2(10, 560), Vector2(w - 20, 60), 24, Color(1, 1, 1, 0.8))
